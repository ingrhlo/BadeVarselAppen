package com.example.badevarselappen.ui.navigation

import android.net.Uri
import androidx.navigation.NavHostController
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.ui.screens.locationWeatherScreen.PresentableMetAlert
import com.google.gson.Gson

/**
 * A class with all the navigational actions that the app can take.
 *
 * @param navController a [NavHostController] that is used to navigate in the app
 * @param routes All [AppDestinations] that the app can navigate to
 */
class AppActions (
    private val navController : NavHostController,
    private val routes : AppDestinations
) {

    //Triggered when user navigates to a specific bathing place
    val selectedLocation : (Coordinates) -> Unit = { coordinates ->
        navController.navigate("${routes.LOCATION_DETAIL_ROUTE}/${coordinates}")
    }

    //Navigates to previous screen
    val navigateUp : () -> Unit = {
        navController.navigateUp()
    }

    //Navigates to screen with specified route
    val navigateTo : (String) -> Unit = {route ->
        navController.navigate(route)
    }

    //Triggered when user navigates to a specific alert
    val selectedAlert : (PresentableMetAlert) -> Unit =  { alert ->
        val json = Uri.encode(Gson().toJson(alert))
        navController.navigate("${routes.ALERT_ROUTE}/${json}")
    }
}