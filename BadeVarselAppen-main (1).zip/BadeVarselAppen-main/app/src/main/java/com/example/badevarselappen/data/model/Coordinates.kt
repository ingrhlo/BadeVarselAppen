package com.example.badevarselappen.data.model

/**
 * Simple data class representing a coordinate on earth
 *
 * @param latitude a latitude coordinate
 * @param longitude a longitude coordinate
 * @param altitude a altitude coordinate. Default is "0", because it is assumed that bathing
 * happens at sea-level.
 */
class Coordinates(
        val latitude : String,
        val longitude : String,
        val altitude : String = "0"
){

        constructor(stringCoordinate : String) : this(
                latitude = stringCoordinate.split(",")[0], //Ugly, but works.
                longitude = stringCoordinate.split(",")[1],
                altitude = stringCoordinate.split(",")[2]
        )
        override fun toString() = "$latitude,$longitude,$altitude"
        override fun equals(other: Any?) = if(other is Coordinates) hashCode() == other.hashCode() else false

        //Generated. Won't take credit for this one.
        override fun hashCode(): Int {
                var result = latitude.hashCode()
                result = 31 * result + longitude.hashCode()
                result = 31 * result + altitude.hashCode()
                return result
        }
}
