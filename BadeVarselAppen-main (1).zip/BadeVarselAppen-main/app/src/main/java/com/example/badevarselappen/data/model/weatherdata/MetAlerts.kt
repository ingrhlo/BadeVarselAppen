package com.example.badevarselappen.data.model.weatherdata

/**
 * Simple dataclass that contains WeatherAlerts from MetAlert API
 * Should be used to hold all WeatherAlerts relevant to a set of coordinates.
 *
 * @param metAlerts a list of WeatherAlert objects
 */
data class MetAlerts (
    val metAlerts: List<MetAlert>
        )