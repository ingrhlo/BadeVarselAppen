package com.example.badevarselappen.data.network.datasourceMet


import com.example.badevarselappen.BuildConfig
import com.example.badevarselappen.data.model.Coordinates
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.*
import io.ktor.client.plugins.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json

/**
 * Abstract object that will return results from an Met API of type [T]. It is built to use HTTPS.
 *
 * @param engine [HttpClientEngine] that inheritors will need to provide.
 */
abstract class DataSourceMet<T>(engine: HttpClientEngine) {
    protected val client = HttpClient(engine) {
        defaultRequest {
            header(BuildConfig.apiKeyHeader, BuildConfig.metApiKey)
            url{
                protocol = URLProtocol.HTTPS
                host = BuildConfig.metBaseAddress
                path(BuildConfig.commonPath)
            }
        }
        install(ContentNegotiation){
            json(
                Json {ignoreUnknownKeys = true }
            )
        }
    }

    /**
     * Method which returns the extra addressing that is added after a base address.
     *
     * @param coordinates the coordinates which the api shall return information about.
     */
    protected abstract fun apiAddress(coordinates: Coordinates) : String

    /**
     * Method which returns the data which the api-call returned.
     *
     * @param coordinates the coordinates which the api shall return information about.
     * @param T return type of the apiData.
     * @return returns null if api call didn't give a OK HttpStatusCode.
     * Else will return a object of type [T]
     * @throws NoTransformationFoundException if no transformation is found for the type T
     */
    protected suspend inline fun <reified T> apiData(coordinates: Coordinates) : T? {
        val response = client.get(apiAddress(coordinates))
        if (response.status != HttpStatusCode.OK) return null
        return response.body()

    }

    /**
     * A method to return data from a datasource.
     * @param coordinates the coordinates of the requested data
     * @return the type that the dataSource is specified for
     */
    abstract suspend fun getData(coordinates: Coordinates) : T?
}
