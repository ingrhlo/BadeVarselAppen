package com.example.badevarselappen.ui.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.badevarselappen.ui.screens.locationWeatherScreen.PresentableMetAlert
import com.example.badevarselappen.ui.screens.locationWeatherScreen.textStyleSmall

/**
 * Reusable component of an iconbutton that shows an alert icon with text under it.
 *
 * @param modifier
 * @param alert [PresentableMetAlert] to show info from
 * @param navigateToAlert action to navigate to Alert. By default, is null
 * @param enabled enables clicking action on the button. By default is set to true
 * @param size of the icon. Default is 125 [Dp]
 */
@Composable
fun AlertIconButtonWithTitleUnder(
    modifier: Modifier = Modifier,
    alert : PresentableMetAlert,
    navigateToAlert : ((PresentableMetAlert) -> Unit)? = null,
    enabled : Boolean = true,
    size : Dp = 125.dp
){
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconButton(
            enabled = enabled,
            modifier = Modifier
                .padding(horizontal = 12.dp)
                .fillMaxWidth()
                .size(size),
            onClick = {
                if (navigateToAlert != null) {navigateToAlert(alert)}
            }
        ) {
            Image(
                imageVector = ImageVector.vectorResource(alert.icon),
                contentDescription = null,
                modifier = Modifier.fillMaxSize()
            )
        }
        Text(
            text = alert.eventName,
            style = textStyleSmall
        )
    }
}