package com.example.badevarselappen.data.model.weatherdata

import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.Measurement

/**
 * Object that holds information gathered from OceanForecast API
 *
 * @param fetchedTimeStamp, the time in UTC that data was fetched from server, as string
 * @param coordinates, geographical location/the coordinates for which the data is relevant to
 * @param waterTemperature, temperature in the water
 * @param current, watercurrent in m/s
 * @param waveHeight, height of waves in meters
 */
data class Ocean (
    val fetchedTimeStamp: String?,
    val coordinates : Coordinates,

    val waterTemperature : Measurement<Double>?,
    val current : Measurement<Double>?,
    val waveHeight : Measurement<Double>?

)