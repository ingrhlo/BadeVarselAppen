package com.example.badevarselappen.data.model.weatherdata

import com.example.badevarselappen.data.model.Coordinates

/**
 * Object that contains the collected data from Loctaionforecast API
 *
 * @param timestamp the time in UTC that data was fetched from server, as string
 * @param coordinates the coordinates for which the data is relevant to
 * @param forecastList a list with WeatherForecast objects that holds more API data
 */

data class LocationForecast(
    val timestamp: String,
    val coordinates: Coordinates,
    val forecastList: MutableList<WeatherForecast?>
    )

