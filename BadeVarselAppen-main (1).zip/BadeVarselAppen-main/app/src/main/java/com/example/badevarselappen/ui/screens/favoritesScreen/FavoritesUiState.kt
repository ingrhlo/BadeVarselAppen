package com.example.badevarselappen.ui.screens.favoritesScreen

import androidx.annotation.StringRes
import com.example.badevarselappen.data.model.BathingPlace

/**
 * Ui State of a [FavoritesScreen].
 */
sealed class FavoritesUiState{
    /**
     * State when [FavoritesViewmodel] has loaded information from repository
     *
     * @param favoriteBathingPlaces list containing all [BathingPlace] to be shown
     */
    data class HasData(
        val favoriteBathingPlaces : List<BathingPlace>
    ): FavoritesUiState()

    /**
     * State when [FavoritesViewmodel] hasn't loaded information from repository yet.
     *
     * @param loadingMessage string resource for showing loading message.
     */
    data class LoadingData(
        @StringRes val loadingMessage : Int
    ) : FavoritesUiState()
}

