package com.example.badevarselappen.ui.screens.locationListScreen

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.example.badevarselappen.R
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.ui.common.LocationList
import com.example.badevarselappen.ui.common.LoadingScreen
import com.example.badevarselappen.ui.navigation.topNavigation.TopNavigationBar

/**
 * Composable screen that shows list over bathing places.
 *
 * @param modifier
 * @param viewModel
 * @param onNavToWeatherScreen used to navigate to LocationWeatherScreen.
 * @param bottomNavigationBar the navigation at bottom bar
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationListScreen(
    modifier : Modifier = Modifier,
    onNavToWeatherScreen: (Coordinates) -> Unit,
    viewModel : LocationListViewModel,
    bottomNavigationBar : @Composable () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {TopNavigationBar(title = stringResource(R.string.LocationListTitle))},
        bottomBar = bottomNavigationBar
    ) { paddingValues ->
        when(uiState){
            is LocationListUiState.HasData -> LocationList(
                modifier = Modifier.padding(paddingValues),
                bathingPlaceList = (uiState as LocationListUiState.HasData).allBathingPlaces,
                onNavToWeatherScreen = onNavToWeatherScreen,
            )
            is LocationListUiState.LoadingData -> LoadingScreen(
                loadingMessage = stringResource((uiState as LocationListUiState.LoadingData).loadingMessage)
            )
        }
    }




}

/*@Preview(showBackground = true)
@Composable
fun ListScreenPreview() {
    LocationListScreen(
        onNavToWeatherScreen = {},
        viewModel = LocationListViewModel(
            repository = WeatherReportRepository(),
            savedState = SavedStateHandle()
        ),
        navigateUp = {}
    )
}*/
