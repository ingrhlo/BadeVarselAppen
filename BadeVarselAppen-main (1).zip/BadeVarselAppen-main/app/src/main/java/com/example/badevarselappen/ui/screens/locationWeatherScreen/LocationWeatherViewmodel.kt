package com.example.badevarselappen.ui.screens.locationWeatherScreen

import androidx.lifecycle.*
import com.example.badevarselappen.R
import com.example.badevarselappen.data.exception.OutsideAreaException
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.repository.WeatherReportRepository
import com.example.badevarselappen.data.model.BathingPlace
import com.example.badevarselappen.data.model.weatherdata.*
import com.example.badevarselappen.data.repository.BathingPlaceRepository
import com.example.badevarselappen.ui.navigation.AppDestinations
import dagger.hilt.android.lifecycle.HiltViewModel
import io.ktor.client.plugins.*
import io.ktor.utils.io.errors.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.nio.channels.UnresolvedAddressException
import javax.inject.Inject

/**
 * Viewmodel for showing detailed weather information for a [BathingPlace]. This viewmodel should
 * not be manually created.
 *
 * @param savedState the [SavedStateHandle] that holds the [BathingPlace] upon the creation of this
 * viewmodel. It should be injected by hilt.
 * @param weatherReportRepository the [WeatherReportRepository] that this viewmodel will get information from.
 * It should be injected by hilt.
 */
@HiltViewModel
class LocationWeatherViewmodel @Inject constructor(
    private val savedState: SavedStateHandle,
    private val weatherReportRepository: WeatherReportRepository,
    private val bathingPlaceRepository: BathingPlaceRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow<LocationWeatherUiState>(
        LocationWeatherUiState.Loading(R.string.LoadingData))
    val uiState : StateFlow<LocationWeatherUiState> = _uiState.asStateFlow()
    init{ updateWeatherReport() }

    /**
     * Method that updates the weather report for the [BathingPlace] of the viewmodel
     */
    fun updateWeatherReport() = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update { tryToGetNewSuccessUiState() }
    }

    private suspend fun tryToGetNewSuccessUiState() : LocationWeatherUiState {
        val bathingPlace: BathingPlace = bathingPlaceRepository.getBathingPlace(
            Coordinates(checkNotNull(savedState[AppDestinations.LOCATION_DETAIL_COORDINATES_KEY]))
        )
        return try {
            val report = weatherReportRepository.getData(bathingPlace.coordinates)
            val isFavorite = bathingPlaceRepository.isFavorite(bathingPlace)
            LocationWeatherUiState.Success(
                forecastDetails = getPresentableForecast(
                    report.locationForecast!!,
                    report.oceanForecast,
                    report.nowCast!!
                ),
                alerts = report.metAlerts?.let { makeAlertsPresentable(it) },
                locationIsFavorite = isFavorite,
                locationName = bathingPlace.name,
                favoritesOption = determineFavoritesOption(isFavorite)
            )
        } catch (e: Exception) {
            LocationWeatherUiState.Error(
                when (e) {
                    is HttpRequestTimeoutException -> R.string.LoadingTimedOut
                    is IOException -> R.string.LoadingConnectionFailed
                    is UnresolvedAddressException -> R.string.LoadingNoInternet
                    is OutsideAreaException -> R.string.ErrorMessageForOutsideAreaException
                    else -> throw e
                }
            )
        }
    }

    /**
     * Method that adds or removes a [BathingPlace] from favorites, depending on wheter or not it
     * is a favorite.
     */
    fun addOrRemoveFromFavorites() = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update {currentState ->
            val bathingPlace : BathingPlace = bathingPlaceRepository.getBathingPlace(
                Coordinates(checkNotNull(savedState[AppDestinations.LOCATION_DETAIL_COORDINATES_KEY])))
            if(currentState !is LocationWeatherUiState.Success) return@update currentState
            if(currentState.locationIsFavorite) {
                bathingPlaceRepository.deleteFavorite(bathingPlace)
            } else{
                bathingPlaceRepository.addToFavorites(bathingPlace)
            }
            return@update currentState.copy(
                locationIsFavorite = !currentState.locationIsFavorite,
                favoritesOption = determineFavoritesOption(!currentState.locationIsFavorite)
            )
        }
    }

    private fun determineFavoritesOption(isFavorite : Boolean) : Int {
        return if (isFavorite) R.string.optionRemoveFavorite else R.string.optionAddFavorite
    }

    /**
     * Submits a name that is changing to be the new name of the favorite [BathingPlace]. If name is
     * too long, 30 chars, or empty, the shown name will be reset to the name [BathingPlace] had
     */
    fun submitName() = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update { currentState ->
            if (currentState !is LocationWeatherUiState.Success) return@update currentState
            if (currentState.shownName.length > 30 || currentState.shownName.isEmpty()) {
                return@update currentState.copy(shownName = currentState.locationName)
            } else {
                val bathingPlace : BathingPlace = bathingPlaceRepository.getBathingPlace(
                    Coordinates(checkNotNull(savedState[AppDestinations.LOCATION_DETAIL_COORDINATES_KEY])))
                bathingPlaceRepository.addToFavorites(
                    bathingPlace.copy(name = currentState.shownName)
                )
                return@update currentState.copy(locationName = currentState.shownName)
            }
        }
    }

    /**
     * Updates the shown name of the [BathingPlace]. It removes newlines from input
     *
     * @param newShown new name to be shown
     */
    fun editShownName(newShown : String) = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update { currentState ->
            if (currentState !is LocationWeatherUiState.Success) return@update currentState
            currentState.copy(shownName = newShown.replace("\n",""))
        }
    }

    /**
     * Updates the state of the keyboard, to either show or not.
     */
    fun upDateKeyboardState() = _uiState.update { currentState ->
        if (currentState !is LocationWeatherUiState.Success) return@update currentState
        currentState.copy(showKeyboard = !currentState.showKeyboard)
    }

    //The following functions should be implemented into domain layer, in the future.
    private fun makeAlertsPresentable(alerts : MetAlerts) = alerts.metAlerts.map { makeAlertPresentable(it) }

    private fun makeAlertPresentable(alert : MetAlert) : PresentableMetAlert{
        return PresentableMetAlert(
            eventName = alert.eventAwarenessName,
            description = alert.description.removePrefix("${alert.type}: "),
            consequences = alert.consequences?.let{splitAndRemoveEmptyLast(it)},
            instructions = splitAndRemoveEmptyLast(alert.instruction),
            icon = AlertSymbols.symbols["${alert.event};${alert.awarenessLevel}"]!!.icon
        )
    }

    private fun getPresentableForecast(
        locationForecast: LocationForecast,
        oceanForecast: OceanForecast?,
        nowCast: NowCast
    ) : PresentableForecast {
        val forecastData = mutableListOf<PresentableForeCastData>()
        if(nowCast.windSpeed != null) forecastData.add(PresentableForeCastData(R.string.wind,nowCast.windSpeed.toString()))
        if(nowCast.precipitationRate != null) forecastData.add(PresentableForeCastData(R.string.precipitationRate,nowCast.precipitationRate.toString()))
        if(nowCast.precipitationAmountNextHour != null) forecastData.add(PresentableForeCastData(R.string.PrecipitationAmount,nowCast.precipitationAmountNextHour.toString()))
        val oceanNow = oceanForecast?.listOcean?.first()
        if(oceanNow?.waveHeight != null) forecastData.add(PresentableForeCastData(R.string.waveHeight,oceanNow.waveHeight.toString()))
        if(oceanNow?.current != null) forecastData.add(PresentableForeCastData(R.string.oceanCurrent,oceanNow.current.toString()))
        return PresentableForecast(
                airWaterHeader = getAirWaterHeader(oceanForecast),
                airWaterNowTemp = getAirWaterNowTemp(nowCast, oceanForecast),
                nextHourIcon = WeatherSymbols.symbols[nowCast.symbolCodeNextHour]!!.symbol,
                nextHourText = WeatherSymbols.symbols[nowCast.symbolCodeNextHour]!!.text,
                next12HourIcon = WeatherSymbols.symbols[locationForecast.forecastList.first()?.symbolCode12h]!!.symbol,
                forecastData = forecastData
        )
    }

    private fun getAirWaterHeader(oceanForecast : OceanForecast?) : String {
        return "Luft ${if (oceanForecast != null) " / Vann" else ""}"
    }

    private fun getAirWaterNowTemp(nowCast : NowCast, oceanForecast : OceanForecast?) : String {
        var ret = "${nowCast.airTemperature?.value} °${
            nowCast.airTemperature?.unit?.first()?.uppercase()
        }"
        if (oceanForecast != null) {
            ret += " / ${oceanForecast.listOcean.first()?.waterTemperature?.value} °${
                oceanForecast.listOcean.first()?.waterTemperature?.unit?.first()?.uppercase()
            }"
        }
        return ret
    }
    private fun splitAndRemoveEmptyLast(string : String) : List<String>{
        val list = string.split(". ").toMutableList()
        if(list.last().all { it == ' ' }) list.removeAt(list.size-1)
        return list
    }

}
