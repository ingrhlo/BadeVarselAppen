package com.example.badevarselappen.ui.common

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/**
 * Simple loading screen
 *
 * @param modifier
 * @param loadingMessage message to display
 */
@Composable
fun LoadingScreen(
    modifier: Modifier = Modifier,
    loadingMessage : String
) {
    Text(
        modifier = modifier,
        text = loadingMessage
    )
}