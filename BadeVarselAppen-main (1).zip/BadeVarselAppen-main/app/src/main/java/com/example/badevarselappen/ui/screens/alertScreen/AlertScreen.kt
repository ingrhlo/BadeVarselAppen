package com.example.badevarselappen.ui.screens.alertScreen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.badevarselappen.R
import com.example.badevarselappen.ui.common.AlertIconButtonWithTitleUnder
import com.example.badevarselappen.ui.common.BulletPointList
import com.example.badevarselappen.ui.navigation.topNavigation.TopNavigationBar
import com.example.badevarselappen.ui.screens.locationWeatherScreen.*

/**
 * Screen that shows all information about one weather alert
 *
 * @param modifier
 * @param viewModel
 * @param onNavControlBackButton action to navigate from the [AlertScreen]
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlertScreen (
    modifier: Modifier = Modifier,
    viewModel: AlertViewModel,
    onNavControlBackButton: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopNavigationBar(
                title = uiState.alert.eventName,
                navigateUp = onNavControlBackButton
            )
        },
    ){contentPadding ->
        LazyColumn(modifier = modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(start = 12.dp)
            .padding(start = 10.dp),
        ) {item {
            WeatherAlertInformation(alert = uiState.alert)
        }}
    }
}


@Composable
private fun WeatherAlertInformation(
    modifier: Modifier = Modifier,
    alert : PresentableMetAlert
){
    Column(
        modifier = modifier
            .padding(horizontal = 12.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.Start
    ) {
        AlertIconButtonWithTitleUnder(
            alert = alert,
            modifier = Modifier.fillMaxWidth(),
            enabled = false
        )
        AlertTextInformation(alert = alert)
    }
}


@Composable
private fun AlertTextInformation(
    modifier: Modifier = Modifier,
    alert: PresentableMetAlert
){
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        BulletPointList(
            modifier = Modifier.fillMaxWidth(),
            textHeader = "${alert.eventName}:",
            textStyleHeader = textStyleMedium,
            bullets = listOf(alert.description),
            textStyleBullets = textStyleSmall,
            bulletSize = 0.dp
        )
        if(alert.consequences != null) BulletPointList(
            modifier = Modifier.fillMaxWidth(),
            textHeader = stringResource(R.string.LocationWeatherConsequensesHeader),
            textStyleHeader = textStyleMedium,
            bullets = alert.consequences,
            textStyleBullets = textStyleSmall,
            bulletSize = 0.dp
        )
        BulletPointList(
            modifier = Modifier.fillMaxWidth(),
            textHeader = stringResource(R.string.LocationWeatherInstructionsHeader),
            textStyleHeader = textStyleMedium,
            bullets = alert.instructions,
            textStyleBullets = textStyleSmall,
            bulletSize = 0.dp
        )
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    WeatherAlertInformation(
        alert = PresentableMetAlert(
            eventName = "Snø",
            description = "Latterlig mye snø har inntruffet området.",
            consequences = listOf(
                "Norge går under.",
                "Det blir ny istid."
            ),
            instructions = listOf(
                "Skaff spader. Lengste instruksen i menneskets historie.",
                "Få panikk!"
            ),
            icon = R.drawable.icon_warning_snow_red)
    )
}