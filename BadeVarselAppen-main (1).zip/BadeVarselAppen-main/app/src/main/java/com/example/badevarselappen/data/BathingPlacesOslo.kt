package com.example.badevarselappen.data

import com.example.badevarselappen.data.model.BathingPlace

/**
 * Class that contains hardcoded a list of [BathingPlace] of Oslo.
 *
 * @param bathingPlaces list of [BathingPlace]s in Oslo
 */
data class BathingPlacesOslo(
    val bathingPlaces: List<BathingPlace> = listOf(
        BathingPlace("Bestemorstranda", "59.82706", "10.75919"),
        BathingPlace("Bekkelagsbadet","59.880211","10.765252"),
        BathingPlace("Bekkensten","59.791873", "10.733265"),
        BathingPlace("Bygdøy sjøbad", "59.910966", "10.666218"),
        BathingPlace("Fiskevollbukta", "59.842099", "10.774080"),
        BathingPlace("Gressholmen", "59.884240", "10.723241"),
        BathingPlace("Hovedøya", "59.895156", "10.724467"),
        BathingPlace("Huk", "59.894776", "10.675539"),
        BathingPlace( "Hvervenbukta", "59.832687", "10.772331"),
        BathingPlace("Hydrostranda", "59.912446", "10.650913"),
        BathingPlace( "Håøya","59.716511","10.554676"),
        BathingPlace("Ingierstrand", "59.818387", "10.749155"),
        BathingPlace("Katten", "59.855143", "10.783185"),
        BathingPlace("Langøyene", "59.870772", "10.718336"),
        BathingPlace("Nordstrand bad", "59.868730", "10.782038"),
        BathingPlace("Operastranda", "59.906565", "10.752626"),
        BathingPlace("Paradisbukta", "59.901978", "10.665598"),
        BathingPlace("Rambergøya", "59.879163", "10.717011"),
        BathingPlace("Skinnerbukta (Malmøya)", "59.865999", "10.754442"),
        BathingPlace("Sollerudstranda","59.912666","10.647461"),
        BathingPlace("Solvikbukta på Malmøya","59.865094","10.749902"),
        BathingPlace("Sørenga sjøbad","59.900924","10.750767"),
        BathingPlace("Tjuvholmen","59.906082","10.719619"),
        BathingPlace("Ulvøya","59.867200","10.770946")
    )
)




