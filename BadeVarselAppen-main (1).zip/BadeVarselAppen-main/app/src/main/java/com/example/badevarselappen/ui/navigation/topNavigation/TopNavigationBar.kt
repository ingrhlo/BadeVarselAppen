package com.example.badevarselappen.ui.navigation.topNavigation


import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.badevarselappen.ui.common.NavigateUpButton

/**
 * A modular navigation bar for the top app bar.
 *
 * @param modifier
 * @param navigateUp action meant to navigate back in the app. As long as [navigateUp] isn't null,
 * the [TopNavigationBar] will show an left arrow.
 * @param topAppActions the app bar's actions. Most often this is only an overflowmenu
 * @param title Title displayed in the top app bar
 */
@Composable
fun TopNavigationBar(
    modifier: Modifier = Modifier,
    navigateUp : (() -> Unit)? = null,
    topAppActions: List<(@Composable () -> Unit)>? = null,
    title : String,
) {
    SmallTopAppBar(
        modifier = modifier
            .drawBehind {
                drawLine(
                    color = Color.LightGray,
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 4.dp.toPx()
                )
            },
        navigationIcon = { if(navigateUp != null) NavigateUpButton(navigateUp = navigateUp) },
        actions = { topAppActions?.forEach { it() } },
        title = {
            Text(
                text = title,
                fontSize = 30.sp,
            )
        }
    )
}