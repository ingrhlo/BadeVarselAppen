package com.example.badevarselappen.data.database

import androidx.room.Dao
import androidx.room.*

@Dao
/**
 * Interface used to create [BathingPlaceDatabase] DAO (database access object)
 */
interface FavoriteBathingPlaceDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertFavoriteBathingPlace(favoriteBathingPlaceEntity: FavoriteBathingPlaceEntity)

    @Query("SELECT * " +
            "FROM ${FavoriteBathingPlaceTables.FAVORITE_BATHING_PLACES} " +
            "WHERE ${FavoriteBathingPlaceTables.COLUMN_LATITUDE} = :latitude " +
                "AND ${FavoriteBathingPlaceTables.COLUMN_LONGITUDE} = :longitude ")
    fun getFavoriteBathingPlaceByCoordinate(latitude : String, longitude : String) : FavoriteBathingPlaceEntity?

    @Query("SELECT * FROM ${FavoriteBathingPlaceTables.FAVORITE_BATHING_PLACES}")
    fun getAllFavoriteBathingPlaces() : List<FavoriteBathingPlaceEntity>

    @Delete
    fun deleteSelectedBathingPlace(favoriteBathingPlaceEntity: FavoriteBathingPlaceEntity)
}