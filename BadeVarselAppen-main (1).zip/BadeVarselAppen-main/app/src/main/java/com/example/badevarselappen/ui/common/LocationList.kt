package com.example.badevarselappen.ui.common

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.badevarselappen.data.model.BathingPlace
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.ui.navigation.topNavigation.TopNavigationBar

/**
 * Screen over list of bathing places.
 *
 * @param modifier modifier for screen.
 * @param bathingPlaceList list of bathing places.
 * @param onNavToWeatherScreen used to move to LocationWeatherScreen.
 */
@Composable
fun LocationList (
    modifier: Modifier = Modifier,
    bathingPlaceList: List<BathingPlace>,
    onNavToWeatherScreen: (Coordinates) -> Unit,
) {
    LazyColumn(modifier = modifier) {
        items(bathingPlaceList) { place ->
            OptionButton(
                place = place,
                modifier = Modifier.padding(8.dp),
                onNavToWeatherScreen = onNavToWeatherScreen
            )
        }
    }
}
/**
 * Button to chose bathing place
 *
 * @param place [BathingPlace] that weather-bathing forecast will show, on click on button.
 * @param modifier modifier for screen.
 * @param onNavToWeatherScreen used to move to LocationWeatherScreen
 */
@Composable
private fun OptionButton(
    place: BathingPlace,
    modifier: Modifier = Modifier,
    onNavToWeatherScreen: (Coordinates) -> Unit,
) {
    TextButton(
        modifier = modifier.fillMaxWidth(),
        onClick = { onNavToWeatherScreen(place.coordinates)},
        shape = RectangleShape
    )
    {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            Text(
                text = place.name,
                fontSize = 25.sp,
                textAlign = TextAlign.Start,
                color = Color.DarkGray
            )
        }
    }
}