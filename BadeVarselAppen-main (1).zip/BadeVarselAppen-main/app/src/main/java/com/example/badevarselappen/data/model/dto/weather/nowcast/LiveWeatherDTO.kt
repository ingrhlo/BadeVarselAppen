package com.example.badevarselappen.data.model.dto.weather.nowcast

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
// DTOs used by NowCast
@Serializable
data class LiveWeatherDTO(
    val properties : PropertiesDTO
)

@Serializable
data class PropertiesDTO(
    @SerialName("meta")
    val metadata: MetadataDTO,
    val timeseries : List<ForecastFromTimeDTO>,
)

@Serializable
data class  MetadataDTO(
    @SerialName("updated_at")
    val updatedAt : String, //All time stamps are in UTC
    val units : UnitsDTO,
    @SerialName("radar_coverage")
    val radarCoverage : String //must be "ok", to give precipitation forecast.
)

@Serializable
data class UnitsDTO(
    @SerialName("air_temperature")
    val airTemperature : String,
    @SerialName("precipitation_amount")
    val precipitationAmount : String,
    @SerialName("precipitation_rate")
    val precipitationRate : String,
    @SerialName("relative_humidity")
    val relativeHumidity : String,
    @SerialName("wind_speed")
    val windSpeed : String,
    @SerialName("wind_speed_of_gust")
    val windSpeedOfGust : String,
)

@Serializable
data class ForecastFromTimeDTO(
    val time : String,
    val data : ForecastDTO
)

@Serializable
data class ForecastDTO(
    val instant : InstantDTO,
    @SerialName("next_1_hours")
    val nextHour : NextHourDTO? = null
)
@Serializable
data class InstantDTO(
    val details : DetailsDTO
)

@Serializable
data class DetailsDTO(
    @SerialName("air_temperature")
    val airTemperature : Double? = null,
    @SerialName("precipitation_amount")
    val precipitationAmount : Double? = null,
    @SerialName("precipitation_rate")
    val precipitationRate : Double? = null,
    @SerialName("relative_humidity")
    val relativeHumidity : Double? = null,
    @SerialName("wind_speed")
    val windSpeed : Double? = null,
    @SerialName("wind_speed_of_gust")
    val windSpeedOfGust : Double? = null,
)

@Serializable
data class NextHourDTO(
    val summary : SummaryDTO,
    val details: DetailsDTO
)

@Serializable
data class SummaryDTO(
    @SerialName("symbol_code")
    val symbolCode : String
)
