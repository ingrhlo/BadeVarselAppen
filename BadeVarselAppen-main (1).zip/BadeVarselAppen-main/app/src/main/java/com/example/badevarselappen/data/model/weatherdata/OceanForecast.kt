package com.example.badevarselappen.data.model.weatherdata

import com.example.badevarselappen.data.model.Coordinates

/**
 * data class that holds a list of Ocean-objects
 *
 * @param timestamp, is updated data
 * @param coordinates, geographical location/the coordinates for which the data is relevant to
 * @param listOcean, holds a list of Ocean-objects
 */
data class OceanForecast(
    val timestamp: String,
    val coordinates: Coordinates,
    var listOcean: MutableList<Ocean?>
)