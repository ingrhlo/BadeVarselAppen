package com.example.badevarselappen.ui.navigation

/**
 * All routes the app can navigate to
 */
object AppDestinations {
    //Default for MVP.
    const val LOCATION_LIST_ROUTE = "locationList"

    //Route to details of bathing place
    const val LOCATION_DETAIL_ROUTE = "location-details"
    //Gives details of selected bathingplace
    const val LOCATION_DETAIL_COORDINATES_KEY = "location-coordinates"

    //Route to favorites
    const val FAVORITES_ROUTE = "favorites"

    //Route to maps
    const val MAPS_ROUTE = "maps"

    //Route to Alert
    const val ALERT_ROUTE = "alert"
    //Gives details of selected alert
    const val ALERT_DETAIL_KEY = "alert-details"

    //Route to bathing rules
    const val RULES_ROUTE = "rules"
}