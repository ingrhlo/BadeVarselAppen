package com.example.badevarselappen.data.model.dto.metalerts

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// Classes used to transfer data from MetAlerts API to WeatherAlert object

@Serializable
data class MetAlertDTO (
    val features : List<FeaturesDTO>
        ) {
}

@Serializable
data class FeaturesDTO (
    @SerialName("when")
    val whenField: IntervalDTO,
    val geometry: GeometryDTO,
    val properties: PropertiesDTO
)

@Serializable
data class IntervalDTO (
    val interval: List<String>
        )

@Serializable
data class GeometryDTO (
    val coordinates: List<List<List<Double>>>
        )

@Serializable
data class PropertiesDTO(
    val area: String,
    val awarenessResponse: String,
    val awarenessSeriousness: String? = null,
    // This is a string including values separated by ;
    @SerialName("awareness_level")
    val awarenessLevel: String,
    @SerialName("awareness_type")
    val awarenessType: String,
    val certainty: String,
    val consequences: String? = null,
    val county: List<Int>,
    // Format: "Update: <relevant (Norwegian) String>"
    val description: String,
    val event: String,
    val eventAwarenessName: String,
    // Format: UTC
    val eventEndingTime: String? = null,
    val geographicDomain: String,
    val instruction: String,
    val severity: String,
    // Summary of most central data for alert
    val title: String,
    val triggerLevel: String? = null,
    val type: String,




)

