package com.example.badevarselappen.ui.screens.googleMapsScreen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.badevarselappen.R
import com.example.badevarselappen.data.repository.BathingPlaceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * HiltViewModel for MapsScreen.
 */
@HiltViewModel
class MapsViewModel @Inject constructor(
    private val bathingPlaceRepository : BathingPlaceRepository
): ViewModel() {

    private val _uiState = MutableStateFlow<MapsUiState>(
        MapsUiState.LoadingData(loadingMessage = R.string.LoadingData)
    )
    val uiState : StateFlow<MapsUiState> = _uiState.asStateFlow()

    init {
        updateList()
    }

    /**
     * Method that updates the list in the [MapsUiState]
     */
    fun updateList(){
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {currentState ->
                val state = when(currentState) {
                    is MapsUiState.HasData -> currentState
                    is MapsUiState.LoadingData -> MapsUiState.HasData(listOf())
                }
                state.copy(favoriteBathingPlaces = bathingPlaceRepository.getAllSortedFavoriteBathingPlaces())
            }
        }
    }
}