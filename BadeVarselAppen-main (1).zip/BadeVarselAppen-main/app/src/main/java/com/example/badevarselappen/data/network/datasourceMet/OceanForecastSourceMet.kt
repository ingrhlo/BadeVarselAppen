package com.example.badevarselappen.data.network.datasourceMet

import com.example.badevarselappen.BuildConfig
import com.example.badevarselappen.data.model.dto.ocean.OceanForecastDTO
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.Measurement
import com.example.badevarselappen.data.model.weatherdata.Ocean
import com.example.badevarselappen.data.model.weatherdata.OceanForecast
import io.ktor.client.engine.*
import io.ktor.client.engine.cio.*
import io.ktor.serialization.*

/**
 * Object to fetch data from OceanForecast API
 *
 * @param engine [HttpClientEngine] that can be provided. Default is a CIO engine.
 */
class OceanForecastSourceMet(engine: HttpClientEngine = CIO.create()) : DataSourceMet<OceanForecast>(engine) {
    override fun apiAddress(coordinates: Coordinates): String {
        return "${BuildConfig.oceanForecast}lat=${coordinates.latitude}&lon=${coordinates.longitude}"
    }

    override suspend fun getData(coordinates: Coordinates): OceanForecast? {
        val oceanForecastDTO : OceanForecastDTO
        try {
            oceanForecastDTO = apiData(coordinates) ?: return null
        } catch (e: JsonConvertException)  {
            return null
        }
        val forecastDetails = oceanForecastDTO.properties.timeseries
        val units = oceanForecastDTO.properties.meta.units
        val oceanList = mutableListOf<Ocean?>()
        forecastDetails.forEach {timeSeries ->
            val oceanObject = timeSeries.data.instant.details
            val ocean = Ocean(
                coordinates = coordinates,
                fetchedTimeStamp = oceanForecastDTO.properties.timeseries.first().time,
                waterTemperature = oceanObject.seaWaterTemperature?.let{ Measurement(it,units.seaWaterTemperature) },
                current = oceanObject.seaWaterSpeed?.let { Measurement(it,units.seaWaterSpeed) },
                waveHeight = oceanObject.seaSurfaceWaveHeight?.let { Measurement(it,units.seaSurfaceWaveHeight) },
            )
        oceanList.add(ocean)
        }

        return OceanForecast(
            timestamp = oceanForecastDTO.properties.meta.updatedAt,
            coordinates = coordinates,
            listOcean = oceanList
        )
    }
}

