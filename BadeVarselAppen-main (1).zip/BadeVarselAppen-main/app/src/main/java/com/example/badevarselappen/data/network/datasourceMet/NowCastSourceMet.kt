package com.example.badevarselappen.data.network.datasourceMet



import com.example.badevarselappen.BuildConfig
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.weatherdata.NowCast
import com.example.badevarselappen.data.model.Measurement
import com.example.badevarselappen.data.model.convertUTCTimeToLocalTimeZone
import com.example.badevarselappen.data.model.dto.weather.nowcast.LiveWeatherDTO
import com.example.badevarselappen.data.model.dto.weather.nowcast.NextHourDTO
import io.ktor.client.engine.*
import io.ktor.client.engine.cio.*

/**
 * Object to fetch data from NowCast API
 *
 * @param engine [HttpClientEngine] that can be provided. Default is a CIO engine. Custom engines
 * should mostly be provided when testing the [NowCastSourceMet]
 */
class NowCastSourceMet(engine: HttpClientEngine = CIO.create()) : DataSourceMet<NowCast>(engine) {
    override fun apiAddress(coordinates: Coordinates): String {
        return "${BuildConfig.nowCast}lat=${coordinates.latitude}&lon=${coordinates.longitude}"}

    override suspend fun getData(coordinates: Coordinates): NowCast? {
        val liveWeatherDTO: LiveWeatherDTO = apiData(coordinates) ?: return null
        val forecastDetails = liveWeatherDTO.properties.timeseries.first().data.instant.details
        val forecastNextHour : NextHourDTO = liveWeatherDTO.properties.timeseries.first().data.nextHour!!
        val units = liveWeatherDTO.properties.metadata.units
        return NowCast(
            coordinates = coordinates,
            fetchedTimeStamp = convertUTCTimeToLocalTimeZone(liveWeatherDTO.properties.metadata.updatedAt),
            airTemperature =  forecastDetails.airTemperature?.let {Measurement(it,units.airTemperature)},
            precipitationAmountNextHour = forecastNextHour.details.precipitationAmount?.let { Measurement(it,units.precipitationAmount) },
            precipitationRate = forecastDetails.precipitationRate?.let { Measurement(it,units.precipitationRate) },
            relativeHumidity = forecastDetails.relativeHumidity?.let{ Measurement(it,units.relativeHumidity) },
            symbolCodeNextHour = forecastNextHour.summary.symbolCode,
            windSpeed = forecastDetails.windSpeed?.let{ Measurement(it,units.windSpeed) },
            windSpeedOfGust = forecastDetails.windSpeedOfGust?.let { Measurement(it,units.windSpeedOfGust) },
        )
    }
}