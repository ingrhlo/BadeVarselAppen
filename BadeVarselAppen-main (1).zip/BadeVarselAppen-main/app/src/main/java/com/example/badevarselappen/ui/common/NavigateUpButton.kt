package com.example.badevarselappen.ui.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.badevarselappen.R

/**
 * A common NavigateUpButton
 *
 * @param modifier
 * @param navigateUp action to primarily navigate up
 */
@Composable
fun NavigateUpButton(
    modifier: Modifier = Modifier,
    navigateUp : () -> Unit
) {
    IconButton(onClick = navigateUp) {
        Image(
            painter = painterResource(
                id = R.drawable.icons_arrow_back
            ),
            contentDescription = null,
            modifier = modifier.padding(2.dp)
        )
    }
}