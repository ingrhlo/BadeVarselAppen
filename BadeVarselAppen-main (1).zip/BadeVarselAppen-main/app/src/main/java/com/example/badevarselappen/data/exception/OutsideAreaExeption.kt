package com.example.badevarselappen.data.exception

/**
 * Exception for when locationForecast is null, because one is outside of the areal of LocationForecast
 */
class OutsideAreaException() : Exception() {
}