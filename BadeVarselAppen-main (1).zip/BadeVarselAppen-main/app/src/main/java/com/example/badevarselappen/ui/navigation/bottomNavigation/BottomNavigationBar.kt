package com.example.badevarselappen.ui.navigation.bottomNavigation

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState

/**
 * A generic bottom navigation bar, displaying name and icons of the bottom navigation items,
 * and being able to navigate to them.
 *
 * @param modifier
 * @param bottomNavItems list of items that is wanted in the bottom navigation bar.@
 * @param navController controller used to make navigation happen.
 */
@Composable
fun BottomNavigationBar(
    modifier: Modifier = Modifier,
    bottomNavItems: List<BottomNavItem>,
    navController: NavController
){
    NavigationBar(
        modifier = modifier
    ){
        bottomNavItems.forEach {item ->
            val selected = item.route == navController.currentBackStackEntryAsState().value?.destination?.route

            NavigationBarItem(
                selected = selected,
                onClick = {navController.navigate(item.route)},
                label = {
                    Text(
                        text = item.name
                    )
                },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.name,
                        tint = if(selected) Color.Blue else Color.Black
                    )
                },
            )
        }
    }
}