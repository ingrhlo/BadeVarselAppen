package com.example.badevarselappen.data.repository

import com.example.badevarselappen.data.BathingPlacesOslo
import com.example.badevarselappen.data.model.BathingPlace
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.database.BathingPlaceDatabase
import com.example.badevarselappen.data.database.bathingPlaceToDatabaseEntity
import com.example.badevarselappen.data.database.databaseEntityAsBathingPlace
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * A repository in Android architecture data layer. This repository's concern is to provide
 * [BathingPlace]s, and to add or remove them from favorites.
 *
 * @param favorites the [BathingPlaceDatabase] that contains the [BathingPlace] that has been saved
 * as favorites
 * @param standardList a list of [BathingPlace] that the [BathingPlaceRepository] always
 * should be able to provide.
 */
@Singleton
class BathingPlaceRepository @Inject constructor(
    private val favorites : BathingPlaceDatabase,
    private val standardList : List<BathingPlace> = BathingPlacesOslo().bathingPlaces
){
    private val favDao = favorites.favoriteBathingPlaceDAO

    /**
     * Method that gives and [BathingPlace] object from specified [coordinates], either by creating,
     * fetching from database or fetching from [standardList]
     *
     * @param coordinates the [coordinates] that is relevant for [BathingPlace]
     * @return [BathingPlace] for given [coordinates]
     */
    suspend fun getBathingPlace(coordinates: Coordinates) : BathingPlace = withContext(Dispatchers.IO){
        val dataBaseElement = favDao.getFavoriteBathingPlaceByCoordinate(
            latitude = coordinates.latitude,
            longitude = coordinates.longitude)
        if(dataBaseElement != null) return@withContext dataBaseElement.databaseEntityAsBathingPlace()
        standardList.forEach { if(it.coordinates == coordinates) return@withContext it }
        return@withContext BathingPlace(coordinates.toString(),coordinates)
    }


    /**
     * Adds [BathingPlace] to underlying [BathingPlaceDatabase]. Will update the entry in
     * [BathingPlaceDatabase], if entry already exists.
     *
     * @param bathingPlace [BathingPlace] to add to favorites
     */
    suspend fun addToFavorites(bathingPlace : BathingPlace) = withContext(Dispatchers.IO){
        favDao.insertFavoriteBathingPlace(bathingPlace.bathingPlaceToDatabaseEntity())
    }

    /**
     * Removes [BathingPlace] from underlying [BathingPlaceDatabase].
     *
     * @param bathingPlace [BathingPlace] to remove from favorites
     */
    suspend fun deleteFavorite(bathingPlace: BathingPlace) = withContext(Dispatchers.IO){
        favDao.deleteSelectedBathingPlace(
            bathingPlace.bathingPlaceToDatabaseEntity()
        )
    }

    /**
     * Checks if [BathingPlace] is in underlying [BathingPlaceDatabase].
     *
     * @param bathingPlace [BathingPlace] to check is in favorites.
     * @return true if [bathingPlace] is in favorites. Else false.
     */
    suspend fun isFavorite(bathingPlace: BathingPlace) : Boolean = withContext(Dispatchers.IO){
        favDao.getFavoriteBathingPlaceByCoordinate(
            latitude = bathingPlace.coordinates.latitude,
            longitude = bathingPlace.coordinates.longitude
        ) != null
    }

    /**
     * A method to get all [BathingPlace] that is saved as favorite in the repository
     *
     * @return All [BathingPlace] that is saved as favorite in the repository, sorted by name
     */
    suspend fun getAllSortedFavoriteBathingPlaces() : List<BathingPlace> = withContext(Dispatchers.IO){
        favDao.getAllFavoriteBathingPlaces().map {
            it.databaseEntityAsBathingPlace()
        }.sortedBy { it.name }
    }

    /**
     * A method to get all [BathingPlace] that the [BathingPlaceRepository] can provide
     *
     * @return list of [BathingPlace] that repository can provide, sorted by name
     */
    suspend fun getAllSortedBathingPlaces() : List<BathingPlace> = withContext(Dispatchers.IO){
        val ret = standardList.toMutableList()
        favDao.getAllFavoriteBathingPlaces().forEach {
            val place = it.databaseEntityAsBathingPlace()
            if(!ret.contains(place)) ret.add(place)
        }
        return@withContext ret.sortedBy { it.name }
    }
}