package com.example.badevarselappen.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.example.badevarselappen.R
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.ui.navigation.topNavigation.TopNavigationBar
import com.example.badevarselappen.ui.screens.googleMapsScreen.MapsUiState
import com.example.badevarselappen.ui.screens.googleMapsScreen.MapsViewModel
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * @Composable MapsScreen that shows a google maps centered on Scandinavia.
 *
 * @param modifier modify look of screen.
 * @param viewModel
 * @param onNavToWeatherScreen action to navigate to screen showing the weather, based on marker
 * created by user click on map.
 * @param bottomNavigationBar the apps navigation at the bottom bar.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapsScreen (
    modifier: Modifier = Modifier,
    viewModel: MapsViewModel,
    onNavToWeatherScreen: (Coordinates) -> Unit,
    bottomNavigationBar : @Composable () -> Unit
) {

    val uiState by viewModel.uiState.collectAsState()
    val currentClick = remember {
        mutableStateOf<LatLng?>(null)
    }
    val oslo = LatLng(64.10, 17.86)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(oslo, 4.2F)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {TopNavigationBar(title = stringResource(R.string.TheWordMap))},
        bottomBar = bottomNavigationBar
    ) { contentPadding ->
        GoogleMap(
            modifier = Modifier.fillMaxSize().padding(contentPadding),
            cameraPositionState = cameraPositionState,
            onMapClick = {
                currentClick.value = it
            },) {
            if (currentClick.value != null) {
                val coordinates = latLngToCoordinates(currentClick.value!!)
                Marker(
                    state = MarkerState(currentClick.value!!),
                    title = coordinates.toString(),
                    onClick = {
                        onNavToWeatherScreen(coordinates)
                        true
                    },
                )
            }
            if (uiState is MapsUiState.HasData ) {
                (uiState as MapsUiState.HasData).favoriteBathingPlaces.forEach { place ->
                    val latLng = LatLng(
                        place.coordinates.latitude.toDouble(),
                        place.coordinates.longitude.toDouble()
                    )
                    Marker(
                        state = MarkerState(position = latLng),
                        title = place.name,
                        onClick = {
                            onNavToWeatherScreen(place.coordinates)
                            true
                        },
                    )
                }
            }
        }
    }
}

/**
 * Method to convert LatLng to Coordinates
 */
fun latLngToCoordinates(latLng: LatLng): Coordinates {
    return Coordinates(
    BigDecimal(latLng.latitude).setScale(3, RoundingMode.HALF_UP).toPlainString(),
    BigDecimal(latLng.longitude).setScale(3, RoundingMode.HALF_UP).toPlainString())
}