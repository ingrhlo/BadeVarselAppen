package com.example.badevarselappen

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

//This is needed to make hilt work.
@HiltAndroidApp
class MainApplication : Application()