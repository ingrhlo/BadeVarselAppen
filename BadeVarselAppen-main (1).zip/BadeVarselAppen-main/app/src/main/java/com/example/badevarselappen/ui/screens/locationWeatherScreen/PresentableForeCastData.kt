package com.example.badevarselappen.ui.screens.locationWeatherScreen

import androidx.annotation.StringRes

/**
 * Data class for showing information in [LocationWeatherScreen]
 *
 * @param header resourceId for descriptive header of data
 * @param data string representation of the collected data related to header
 */
data class PresentableForeCastData(
    @StringRes val header : Int,
    val data : String
)

