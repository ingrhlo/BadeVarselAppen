package com.example.badevarselappen.data.model

/**
 * This class is a representation of a cache, implemented as an extension of a [LinkedHashMap].
 * This class' primary concern is to set a cap on how many elements can be saved in the cache, and
 * removing the oldest accessed-entry if putting a new element in the cache, while it's full.
 * That will ensure the class always has a number of fresh entries that does not exceed the *maxsize*.
 *
 * @param maxSize the max amount of entries in the cache
 * @param K type of the keys to get the values of the entries
 * @param V type of the values in the entries
 * @constructor Creates an empty Cache with the given maxsize
 */
class Cache<K,V>(
    private val maxSize : Int,
    ) : LinkedHashMap<K,V>() {
    override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>?) = size > maxSize

    /**
     * Like in normal hashmaps, the [put]-method will add an entry to this cache. If the key isn't
     * already assigned, the new entry will be the last entry in the iteration-order of the cache.
     * If updating an already assigned key, the updated entry will be the last entry in the
     * iteration-order, because then it's the most recently accessed entry.
     *
     * @param key key with which the specified value is to be associated
     * @param value the value to be associated with the specified key
     * @return the previous value associated with key, or null if there was no mapping for key.
     */
    override fun put(key: K, value: V): V? {
        remove(key)
        return super.put(key, value)
    }

    /**
     * Like in a normal [LinkedHashMap], the [get]-method will return an value associated with a key,
     * or null,if no value is associated with the key. What the [Cache] does differently, is that it
     * will also set the latest accessed entry as the last element in the iteration-order. Since it's
     * the last accessed entry, it's also likely that it will be needed again, and therefore wise
     * not to remove it before it's the oldest accessed entry.
     *
     * @param key key whose associated value is to be returned
     * @return the value associated with the key
     */
    override fun get(key: K): V? {
        val ret = super.get(key)
        if(ret != null) put(key,ret)
        return ret
    }
}