package com.example.badevarselappen.ui.screens.locationListScreen

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.badevarselappen.R
import com.example.badevarselappen.data.repository.BathingPlaceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 *
 * Viewmodel for [LocationListScreen]. This viewmodel should
 * not be manually created.
 *
 * @param savedState for future expansion options. It should be injected by hilt.
 * @param bathingPlaceRepository the [BathingPlaceRepository] that this viewmodel will get information from.
 * It should be injected by hilt.
 */
@HiltViewModel
class LocationListViewModel @Inject constructor(
    savedState: SavedStateHandle,
    private val bathingPlaceRepository: BathingPlaceRepository
): ViewModel() {
    private val _uiState = MutableStateFlow<LocationListUiState>(
        LocationListUiState.LoadingData(loadingMessage = R.string.LoadingData)
    )
    val uiState : StateFlow<LocationListUiState> = _uiState.asStateFlow()

    init { updateList() }

    /**
     * Method that updates the list in the [LocationListUiState]
     */
    fun updateList() = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update {currentState ->
            val state = when(currentState) {
                is LocationListUiState.HasData -> currentState
                is LocationListUiState.LoadingData -> LocationListUiState.HasData(listOf())
            }
            state.copy(allBathingPlaces = bathingPlaceRepository.getAllSortedBathingPlaces())
        }
    }
}