package com.example.badevarselappen.data.model

import java.text.SimpleDateFormat
import java.util.*

/**
 * Class that converts UTC time to local timezone of object.
 * Will also change date if needed.
 *
 * @param Date string with time and date in UTC
 * @return string with time and date in local timezone
 */
fun convertUTCTimeToLocalTimeZone(Date: String): String {
    return Date.toDate().formatTo("yyyy-MM-dd HH:mm:ss")
}

private fun String.toDate(dateFormat: String = "yyyy-MM-dd'T'HH:mm:ss", timeZone: TimeZone = TimeZone.getTimeZone("UTC")): Date {
    val parser = SimpleDateFormat(dateFormat, Locale.getDefault())
    parser.timeZone = timeZone
    return parser.parse(this)!!
}

private fun Date.formatTo(dateFormat: String, timeZone: TimeZone = TimeZone.getDefault()): String {
    val formatter = SimpleDateFormat(dateFormat, Locale.getDefault())
    formatter.timeZone = timeZone
    return formatter.format(this)
}