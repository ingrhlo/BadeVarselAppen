package com.example.badevarselappen.ui.navigation.navtype

import android.os.Bundle
import androidx.navigation.NavType
import com.example.badevarselappen.ui.screens.locationWeatherScreen.PresentableMetAlert
import com.google.gson.Gson

/**
 * A class for the [NavType] of the [PresentableMetAlert]. It is normally not advised to use complex
 * types for [NavType], but the [PresentableMetAlert] is not something the app should have an own
 * database for, nor does it make sense to Id them and have a repository for them at this time.
 */
class AlertType : NavType<PresentableMetAlert>(isNullableAllowed = false){
    override fun get(bundle: Bundle, key: String): PresentableMetAlert? {
        //Is deprecated at API 33, but we're using API 26.
        return bundle.getParcelable(key)
    }

    override fun parseValue(value: String): PresentableMetAlert {
        return Gson().fromJson(value, PresentableMetAlert::class.java)
    }

    override fun put(bundle: Bundle, key: String, value: PresentableMetAlert) {
        bundle.putParcelable(key, value)
    }

}