package com.example.badevarselappen.data.network.datasourceMet

import com.example.badevarselappen.BuildConfig
import com.example.badevarselappen.data.exception.OutsideAreaException
import com.example.badevarselappen.data.model.dto.weather.locationforecast.LocationForecastDTO
import com.example.badevarselappen.data.model.weatherdata.LocationForecast
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.Measurement
import com.example.badevarselappen.data.model.weatherdata.WeatherForecast
import io.ktor.client.engine.*
import io.ktor.client.engine.cio.*
import io.ktor.serialization.*

/**
 * Object to fetch data from Locationforecast API
 *
 * @param engine [HttpClientEngine] that can be provided. Default is a CIO engine.
 */
class LocationForecastSourceMet(engine: HttpClientEngine = CIO.create())
    : DataSourceMet<LocationForecast>(engine) {
    override fun apiAddress(coordinates: Coordinates): String {
        return "${BuildConfig.locationForecast}lat=${coordinates.latitude}&lon=${coordinates.longitude}"
    }

     override suspend fun getData(coordinates: Coordinates) : LocationForecast?{
         val locationForecastDTO : LocationForecastDTO
         try {
             locationForecastDTO = apiData(coordinates) ?: return null
         } catch (e: JsonConvertException) {
             throw OutsideAreaException()
         }
        val timeSeries = locationForecastDTO.properties.timeseries
        val forecastList = mutableListOf<WeatherForecast?>()
        val units = locationForecastDTO.properties.meta.units
        timeSeries.forEach { instantForeCast ->
            val forecastdetails = instantForeCast.data.instant.details
            val precipitation12h = instantForeCast.data.next12Hours?.details?.probabilityOfPrecipitation
            val forecastObject = instantForeCast.data.next12Hours?.summary?.let { summary ->
                WeatherForecast(
                    time =  instantForeCast.time,
                    airTemperature = forecastdetails.airTemperature?.let { Measurement(it,units.airTemperature) },
                    cloudiness =  forecastdetails.cloudiness?.let { Measurement(it,units.cloudiness) },
                    fog = forecastdetails.fog?.let { Measurement(it,units.fog) },
                    relativeHumidity = forecastdetails.relativeHumidity?.let { Measurement(it,units.relativeHumidity) },
                    ultravioletIndex = forecastdetails.ultravioletIndex?.let { Measurement(it,units.ultravioletIndex) },
                    windSpeed = forecastdetails.windSpeed?.let { Measurement(it,units.windSpeed) },
                    probabilityOfPrecipitation12h = precipitation12h?.let { Measurement(it,units.probabilityOfPrecipitation) },
                    symbolCode12h = instantForeCast.data.next12Hours.summary.symbolCode,
                    symbolConfidence12h = summary.symbolConfidence
                )
            }
            forecastList.add(forecastObject)
        }
        return LocationForecast(
            timestamp  = locationForecastDTO.properties.meta.updatedAt,
            coordinates = coordinates,
            forecastList = forecastList
        )
    }
}