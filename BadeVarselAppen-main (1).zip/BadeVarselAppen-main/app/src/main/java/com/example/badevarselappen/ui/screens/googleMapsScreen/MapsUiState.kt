package com.example.badevarselappen.ui.screens.googleMapsScreen

import androidx.annotation.StringRes
import com.example.badevarselappen.data.model.BathingPlace

/**
 * UiState of [MapsScreen]
 */
sealed class MapsUiState {
    /**
     * State when [MapsViewModel] has loaded information from repository
     *
     * @param favoriteBathingPlaces list containing all [BathingPlace] to be marked
     */
    data class HasData(
        val favoriteBathingPlaces : List<BathingPlace>
    ): MapsUiState()

    /**
     * State when [MapsViewModel] hasn't loaded information from repository yet.
     *
     * @param loadingMessage string resource for showing loading message.
     */
    data class LoadingData(
        @StringRes val loadingMessage : Int
    ) : MapsUiState()

}