package com.example.badevarselappen.ui.navigation.topNavigation

/**
 * Simple data class to hold information about what a text option will do in an overflow menu.
 *
 * @param text displayed text in overflow menu
 * @param action that will happen when option is clicked
 */
data class MenuOption(
    val text : String,
    val action : () -> Unit
)
