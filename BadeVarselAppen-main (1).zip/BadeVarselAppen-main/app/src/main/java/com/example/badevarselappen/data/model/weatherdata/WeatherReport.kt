package com.example.badevarselappen.data.model.weatherdata

import com.example.badevarselappen.data.model.Coordinates
import java.time.ZonedDateTime

/**
 * Object that holds collected data from the OceanForecast, WeatherForecast, NowCast and MetAlerts
 * API
 *
 * @param coordinates the coordinates which the [WeatherReport] is relevant for
 * @param createdTimeStamp the time which the [WeatherReport] was made
 * @param oceanForecast collected data from OceanForecast API
 * @param locationForecast collected data from WeatherForecast API
 * @param nowCast collected data from NowCast API
 * @param metAlerts collected data from MetAlerts API
 */
data class WeatherReport(
    val coordinates: Coordinates,
    val createdTimeStamp : ZonedDateTime = ZonedDateTime.now(),
    val oceanForecast : OceanForecast? = null,
    val locationForecast : LocationForecast? = null,
    val nowCast: NowCast? = null,
    val metAlerts : MetAlerts? = null
    ) : Comparable<WeatherReport>{
    override fun compareTo(other: WeatherReport) = createdTimeStamp.compareTo(other.createdTimeStamp)
}


