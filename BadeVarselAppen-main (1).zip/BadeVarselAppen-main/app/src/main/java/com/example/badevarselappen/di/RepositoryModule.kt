package com.example.badevarselappen.di

import com.example.badevarselappen.data.repository.WeatherReportRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton


@InstallIn(SingletonComponent::class)
@Module
/**
 * Object that provides [WeatherReportRepository] for objects that require injected
 * [WeatherReportRepository] in their constructor
 */
object RepositoryModule {
    @Singleton
    @Provides
    fun provideRepository() = WeatherReportRepository()
}