package com.example.badevarselappen.di

import com.example.badevarselappen.data.BathingPlacesOslo
import com.example.badevarselappen.data.repository.WeatherReportRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
/**
 * Object that provides [BathingPlacesOslo] for objects that require injected
 * [BathingPlacesOslo] in their constructor
 */
object StandardBathingPlaceModule {
    @Singleton
    @Provides
    fun providePlaces() = BathingPlacesOslo().bathingPlaces
}