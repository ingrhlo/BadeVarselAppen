package com.example.badevarselappen.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp


/**
 * List with bullet points. Note; The bullets do not line up properly as of now.
 *
 * @param modifier
 * @param bulletSize the size of the bullets. 4.dp i default.
 * @param color color of the bullet. Black is default.
 * @param shape shape of bullet. Circle is default
 * @param textHeader header text of list
 * @param textStyleHeader textstyle of header
 * @param bullets list of strings that will be bulleted.
 * @param textStyleBullets textstyle applied to the bullets.
 */
@Composable
fun BulletPointList(
    modifier: Modifier = Modifier,
    bulletSize : Dp = 4.dp,
    color : Color = Color.Black,
    shape : Shape = CircleShape,
    textHeader : String,
    textStyleHeader: TextStyle,
    bullets : List<String>,
    textStyleBullets : TextStyle,
    bulletSpace : Dp = 10.dp
){
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(bulletSpace)
    ) {
        Text(
            text = textHeader,
            style = textStyleHeader
        )
        bullets.forEach {
            BulletPoint(
                text = it,
                textStyle = textStyleBullets,
                bulletSize = bulletSize,
                color = color,
                shape = shape
            )
        }
    }
}

@Composable
private fun BulletPoint(
    bulletSize : Dp,
    color : Color,
    shape : Shape,
    text : String,
    textStyle: TextStyle
){
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier
            .padding(start = 16.dp, end = 8.dp)
            .size(bulletSize)
            .background(color, shape = shape)
        )
        Text(
            text = text,
            style = textStyle
        )
    }
}