package com.example.badevarselappen.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.badevarselappen.ui.MapsScreen
import com.example.badevarselappen.ui.screens.googleMapsScreen.MapsViewModel
import com.example.badevarselappen.ui.navigation.bottomNavigation.AppBottomNavigationBar
import com.example.badevarselappen.ui.navigation.navtype.AlertType
import com.example.badevarselappen.ui.screens.alertScreen.AlertScreen
import com.example.badevarselappen.ui.screens.alertScreen.AlertViewModel
import com.example.badevarselappen.ui.screens.BathingRulesScreen
import com.example.badevarselappen.ui.screens.favoritesScreen.FavoritesScreen
import com.example.badevarselappen.ui.screens.favoritesScreen.FavoritesViewmodel
import com.example.badevarselappen.ui.screens.locationListScreen.LocationListScreen
import com.example.badevarselappen.ui.screens.locationListScreen.LocationListViewModel
import com.example.badevarselappen.ui.screens.locationWeatherScreen.LocationWeatherScreen
import com.example.badevarselappen.ui.screens.locationWeatherScreen.LocationWeatherViewmodel

/**
 * The function that let's the app navigate from one screen to another
 *
 * @param startDestination Starting destination of the app
 * @param routes all [AppDestinations] of the app
 */
@Composable
    fun AppNavigation(
    startDestination: String = AppDestinations.MAPS_ROUTE,
    routes : AppDestinations = AppDestinations
) {
    val navController = rememberNavController()
    val actions = remember(navController){
        AppActions(navController, routes)
    }

    /**
     * With the [AppBottomNavigationBar], the app can navigate to [LocationListScreen], [FavoritesScreen],
     * maps screen
     */
    val bottomNavigationBar = @Composable{ AppBottomNavigationBar(navController = navController)}


        NavHost(
            navController = navController,
            startDestination = startDestination
        ){
            /**
             * Navigates to [LocationListScreen]. From there one can navigate to [LocationWeatherScreen]
             * It can also navigate using the [AppBottomNavigationBar]
             */
            composable(
                route = routes.LOCATION_LIST_ROUTE
            ){
                val locationListViewModel = hiltViewModel<LocationListViewModel>()
                locationListViewModel.updateList() //This does not seem nice, but it works.
                LocationListScreen(
                    onNavToWeatherScreen = actions.selectedLocation,
                    viewModel = locationListViewModel,
                    bottomNavigationBar = bottomNavigationBar
                )
            }

            /**
             * Navigates to [LocationWeatherScreen]. From there, one can navigate to eventual alerts,
             * or navigate up.
             */
            composable(
                //The way this magic works, is that the navhost will navigate to
                // "${routes.LOCATION_DETAIL_ROUTE}/[INSERT SOME ID HERE]", then that id will
                //be saved to the viewmodel's saved state-handle as a mapping of
                // routes.LOCATION_DETAIL_ID_KEY to [INSERT SOME ID HERE] due to the navArgument
                route = "${routes.LOCATION_DETAIL_ROUTE}/{${routes.LOCATION_DETAIL_COORDINATES_KEY}}",
                arguments = listOf(
                    navArgument(routes.LOCATION_DETAIL_COORDINATES_KEY){type = NavType.StringType}
                )
            ){
                val locationWeatherViewmodel = hiltViewModel<LocationWeatherViewmodel>()
                LocationWeatherScreen(
                    onNavControlBackButton = actions.navigateUp,
                    navigateToAlert = actions.selectedAlert,
                    viewModel = locationWeatherViewmodel
                )
            }

            /**
             * Navigates to [FavoritesScreen]. From there one can navigate to [LocationWeatherScreen]
             * It can also navigate using the [AppBottomNavigationBar]
             */
            composable(
                route = routes.FAVORITES_ROUTE
            ){
                val favoritesViewmodel = hiltViewModel<FavoritesViewmodel>()
                favoritesViewmodel.updateList() //This does not seem nice, but it works.
                FavoritesScreen(
                    viewmodel = favoritesViewmodel,
                    onNavToWeatherScreen = actions.selectedLocation,
                    bottomNavigationBar = bottomNavigationBar,
                )
            }


            /**
             * Upcoming navigation for maps screen
             */
            composable(
                route = routes.MAPS_ROUTE
            ){
                val mapsViewModel = hiltViewModel<MapsViewModel>()
                mapsViewModel.updateList()
                MapsScreen(
                    onNavToWeatherScreen = actions.selectedLocation,
                    viewModel = mapsViewModel,
                    bottomNavigationBar = bottomNavigationBar,
                    )
            }
            composable(
                route = routes.RULES_ROUTE
            ){
                BathingRulesScreen(
                    onNavControllBackButton = actions.navigateUp,
                    bottomNavigationBar = bottomNavigationBar,
                )
            }

            /**
             * Navigates to [AlertScreen]. From there, one can only navigate back
             */
            composable(
                //Not best solution to use such complex type for navigation
                route = "${routes.ALERT_ROUTE}/{${routes.ALERT_DETAIL_KEY}}",
                arguments = listOf(
                    navArgument(routes.ALERT_DETAIL_KEY){type = AlertType() }
                )
            ){
                val alertViewModel = hiltViewModel<AlertViewModel>()
                AlertScreen(
                    onNavControlBackButton = actions.navigateUp,
                    viewModel = alertViewModel
                )
            }

        }

}