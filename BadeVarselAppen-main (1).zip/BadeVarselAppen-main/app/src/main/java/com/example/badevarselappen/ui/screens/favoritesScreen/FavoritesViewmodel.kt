package com.example.badevarselappen.ui.screens.favoritesScreen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.badevarselappen.R
import com.example.badevarselappen.data.repository.BathingPlaceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Viewmodel for [FavoritesScreen]. Should not be created manually.
 *
 * @param bathingPlaceRepository the repository that the viewmodel will fetch data from. Should be
 * injected with dagger-hilt.
 */
@HiltViewModel
class FavoritesViewmodel @Inject constructor(
    private val bathingPlaceRepository : BathingPlaceRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow<FavoritesUiState>(
        FavoritesUiState.LoadingData(loadingMessage = R.string.LoadingData)
    )
    val uiState : StateFlow<FavoritesUiState> = _uiState.asStateFlow()

    init { updateList() }

    /**
     * Method that updates the list in the [FavoritesUiState]
     */
    fun updateList() = viewModelScope.launch(Dispatchers.IO) {
        _uiState.update {currentState ->
            val state = when(currentState) {
                is FavoritesUiState.HasData -> currentState
                is FavoritesUiState.LoadingData -> FavoritesUiState.HasData(listOf())
            }
            state.copy(favoriteBathingPlaces = bathingPlaceRepository.getAllSortedFavoriteBathingPlaces())
        }
    }
}