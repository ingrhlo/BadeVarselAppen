package com.example.badevarselappen.ui.screens.alertScreen

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.example.badevarselappen.ui.navigation.AppDestinations
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

/**
 * The viewmodel of an [AlertScreen]
 *
 * @param savedState bundle from which the alert is fetched
 */
@HiltViewModel
class AlertViewModel @Inject constructor(
    private val savedState: SavedStateHandle,
) : ViewModel() {

    private val _uiState = MutableStateFlow(getPresentableMetAlert())
    val uiState : StateFlow<AlertUiState> = _uiState.asStateFlow()

    private fun getPresentableMetAlert() = AlertUiState(
        checkNotNull(savedState[AppDestinations.ALERT_DETAIL_KEY])
    )
}
