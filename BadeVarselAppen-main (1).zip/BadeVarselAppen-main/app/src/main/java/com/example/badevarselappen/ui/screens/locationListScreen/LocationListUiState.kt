package com.example.badevarselappen.ui.screens.locationListScreen

import androidx.annotation.StringRes
import com.example.badevarselappen.data.model.BathingPlace

sealed class LocationListUiState{
    /**
     * State when [LocationListViewModel] has loaded information from repository
     *
     * @param allBathingPlaces list containing all [BathingPlace] to be shown
     */
    data class HasData(
        val allBathingPlaces : List<BathingPlace>
    ): LocationListUiState()

    /**
     * State when [LocationListViewModel] hasn't loaded information from repository yet.
     *
     * @param loadingMessage string resource for showing loading message.
     */
    data class LoadingData(
        @StringRes val loadingMessage : Int
    ) : LocationListUiState()
}