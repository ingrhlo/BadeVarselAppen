package com.example.badevarselappen.ui.screens.locationWeatherScreen

/**
 * Simple singleton object that holds a mapping of all the weather symbols
 */
object WeatherSymbols {
    val symbols = WeatherSymbol.values().associateBy { it.symbolcode }
}