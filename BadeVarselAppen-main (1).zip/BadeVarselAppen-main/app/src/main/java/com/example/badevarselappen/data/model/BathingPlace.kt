package com.example.badevarselappen.data.model

/**
 * Objects that holds basic geographical information about the locations where people might bathe.
 *
 * @param name the [BathingPlace] name
 * @param coordinates the [coordinates] of the [BathingPlace]
 */
data class BathingPlace(
    val name: String,
    val coordinates: Coordinates
){
    constructor(name: String, latitude : String, longitude : String) :
            this(name, Coordinates(latitude, longitude))

    constructor(coordinates: Coordinates) : this(coordinates.toString(),coordinates)
}
