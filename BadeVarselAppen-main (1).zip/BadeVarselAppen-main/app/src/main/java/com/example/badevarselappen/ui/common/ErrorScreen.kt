package com.example.badevarselappen.ui.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.badevarselappen.R
import com.example.badevarselappen.ui.screens.locationWeatherScreen.textStyleBig
import com.example.badevarselappen.ui.screens.locationWeatherScreen.textStyleSmall

/**
 * Simple error screen with retry button.
 *
 * @param modifier
 * @param errorMessage message to display
 *
 */

@Composable
fun ErrorScreen(
    modifier: Modifier = Modifier,
    errorMessage: String,
    retryAction: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(R.string.oops),
            style = textStyleBig,
        )

        Image(
            modifier = modifier.size(250.dp),
            painter = painterResource(id = R.drawable.x_eyes),
            contentDescription = null
        )
        Text(
            text = stringResource(R.string.generalErrorMessage),
            style = textStyleSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = errorMessage,
            style = textStyleSmall,
            fontWeight = FontWeight.Bold
        )
        Button(
            onClick = retryAction,
            colors = ButtonDefaults.buttonColors(Color.Blue),
            shape = RoundedCornerShape(25),
            modifier = modifier.padding(top = 10.dp)
        ) {
            Text(
                text = stringResource(R.string.tryAgain),
                fontSize = 20.sp,
            )
        }
    }
}