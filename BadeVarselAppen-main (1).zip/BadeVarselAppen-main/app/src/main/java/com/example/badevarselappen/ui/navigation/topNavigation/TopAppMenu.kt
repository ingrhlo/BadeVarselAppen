package com.example.badevarselappen.ui.navigation.topNavigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*

/**
 * A generic overflow menu meant to be at the top of the app.
 *
 * @param menuOptions list of options that the menu will have.
 */
@Composable
fun TopAppMenu(
    menuOptions : List<MenuOption>
){
    var showMenu by remember{ mutableStateOf(false) }
    IconButton(
        onClick = { showMenu = !showMenu }
    ) {
        Icon(
            imageVector = Icons.Outlined.Menu,
            contentDescription = null,
        )
    }
    DropdownMenu(
        expanded = showMenu,
        onDismissRequest = { showMenu = false }
    ) {
        menuOptions.forEach { option ->
            DropdownMenuItem(
                text = {Text(option.text)},
                onClick = option.action
            )
        }
    }
}
