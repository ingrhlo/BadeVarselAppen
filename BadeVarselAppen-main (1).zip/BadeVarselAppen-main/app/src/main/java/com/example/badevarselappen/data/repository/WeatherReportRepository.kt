package com.example.badevarselappen.data.repository

import com.example.badevarselappen.data.model.Cache
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.weatherdata.WeatherReport
import com.example.badevarselappen.data.network.datasourceMet.OceanForecastSourceMet
import com.example.badevarselappen.data.network.datasourceMet.LocationForecastSourceMet
import com.example.badevarselappen.data.network.datasourceMet.MetAlertsSourceMet
import com.example.badevarselappen.data.network.datasourceMet.NowCastSourceMet
import java.time.ZonedDateTime
import kotlinx.coroutines.*
import java.util.*

/**
 * A repository in android architecture's datalayer. The primary concern of this class, is to gather,
 * hold and provide fresh [WeatherReport]-objects that the UI-layer can use.
 *
 * @param maxCacheSize the max amount of [WeatherReport]-objects that the repository can store at a
 * given time. Default is 1000, on the assumption that 1000 is plenty.
 *
 * @param lifetimeMinutesInCache the lifetime of the [WeatherReport]-objects. The repository will
 * not return objects that are older than that lifetime. Default is 5, seeing as the gathered
 * live-data gives time-series forecast for 5-minutes intervals. Values < 0 will throw [IllegalArgumentException]
 *
 * @param decimalCoordinatePrecision the accepted precision of the coordinates. Higher precision
 * will be rounded to closest accepted precision. Lower precision will get *0*-s added behind, to
 * give a meaningfully comparison to *decimalCoordinatePrecision*. Default is 3, that gives a radius
 * of 111m in precision, and it's assumed that weather doesn't change much in a 111m radius.
 *
 * @constructor Creates an empty repository.
 */
class WeatherReportRepository(
    maxCacheSize : Int = 1000,
    private val lifetimeMinutesInCache : Long = 5,
    private val decimalCoordinatePrecision : Int = 3
) {
    init {
        if(decimalCoordinatePrecision < 0) throw IllegalArgumentException("DecimalCoordinatePrecision must be greater or equal to 0!")
    }

    private val cache = Cache<Coordinates, WeatherReport>(maxSize = maxCacheSize)
    private val nowCastSource = NowCastSourceMet()
    private val locationForecastSource = LocationForecastSourceMet()
    private val oceanForecastSource = OceanForecastSourceMet()
    private val alertsSource = MetAlertsSourceMet()


    /**
     * A method that returns a weather report that is fresher than [lifetimeMinutesInCache]
     *
     * @param rawCoordinates the requested coordinates to fetch a [WeatherReport] from
     */
    suspend fun getData(rawCoordinates: Coordinates): WeatherReport {
        val coordinates = adjustToPrecision(rawCoordinates.latitude,rawCoordinates.longitude)
        val report = cache[coordinates] ?: return createNewReport(coordinates)
        if (report.createdTimeStamp < ZonedDateTime.now().minusMinutes(lifetimeMinutesInCache)) return createNewReport(coordinates)
        return report
    }

    private suspend fun createNewReport(coordinates: Coordinates) = withContext(Dispatchers.IO){
        val liveWeather = async {nowCastSource.getData(coordinates)}
        val weatherForecast = async {locationForecastSource.getData(coordinates)}
        val oceanForecast = async {oceanForecastSource.getData(coordinates)}
        val alerts = async{alertsSource.getData(coordinates)}

        val newReport = WeatherReport(
            coordinates = coordinates,
            nowCast = liveWeather.await(),
            locationForecast = weatherForecast.await(),
            oceanForecast = oceanForecast.await(),
            metAlerts = alerts.await()
        )
        cache[coordinates] = newReport
        return@withContext newReport
    }

    private fun adjustToPrecision(latitude: String, longitude: String) : Coordinates {
        val newLatitude = String.format(
            locale = Locale.ENGLISH,
            format = "%.${decimalCoordinatePrecision}f",
            latitude.toFloat()
        )
        val newLongitude = String.format(
            locale = Locale.ENGLISH,
            format = "%.${decimalCoordinatePrecision}f",
            longitude.toFloat()
        )
        return Coordinates(newLatitude,newLongitude)
    }
}