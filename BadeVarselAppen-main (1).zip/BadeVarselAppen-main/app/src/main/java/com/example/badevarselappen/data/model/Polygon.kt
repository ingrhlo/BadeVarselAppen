package com.example.badevarselappen.data.model

/**
 * A representation of a Polygon.
 *
 * @param coordinatesList A list of coordinate pairs in order (x,y), which is the same as
 * order (longitude,latitude)
 */
class Polygon (coordinatesList: List<List<Double>>){
    //Private class to store interesting calculations, that would otherwise bloat this document.
    private class ValuesOfInterest(
        targetLocation: Coordinates,
        linePointA: Coordinates,
        linePointB: Coordinates
    ){
        //We have earlier assumed order of coordinates to be ordered (latitude,longitude).
        //The doubles is however in (longitude,latitude) for an (x,y) order.
        //See: https://docs.api.met.no/doc/GeoJSON.html
        val yt = targetLocation.latitude.toDouble()
        val xt = targetLocation.longitude.toDouble()
        val ya = linePointA.latitude.toDouble()
        val xa = linePointA.longitude.toDouble()
        val yb = linePointB.latitude.toDouble()
        val xb = linePointB.longitude.toDouble()

        val rise: Double = yb-ya
        val run: Double = xb-xa

        private val slope : Double
            get() = rise/run

        //Follows y=ax+b to find the intersection point when we move from (xa,ya)
        val intersectionX : Double
            get() = xa + ((yt-ya)/slope)

        val targetAboveSegment = yt > ya && yt > yb
        val targetLeftOfSegment = xt < xb && xt < xa
        val targetRightOfSegment = xt > xb && xt > xa
        val targetBelowSegment = yt < ya && yt < yb
    }


    private val coordinateList: List<Coordinates> = coordinatesList.map { xyDoubles->
        Coordinates(xyDoubles[1].toString(), xyDoubles[0].toString())
    }

    /**
     * Method calculates checks if [coordinates] is covered by the [Polygon]. It does so by
     * raytracing an infinite ray from the point specified by [coordinates], and checking how many
     * line segments the ray crosses. If the amount is even, then the [coordinates] is outside of
     * the [Polygon]. If the amount of line segments crossed is odd, then the [coordinates] is
     * inside, and covered, by the [Polygon]
     *
     * @param [coordinates] to check
     * @return true if [coordinates] is within the polygon, else false
     */
    fun covers(coordinates: Coordinates): Boolean{
        var linesCrossed = 0
        for (i in 0..coordinateList.size-2) {
            val valuesOfInterest = ValuesOfInterest(coordinates,coordinateList[i],coordinateList[i+1])
            if (isOnEdge(valuesOfInterest)) return true
            if (linesCross(valuesOfInterest)) linesCrossed++
        }
        if (linesCross(ValuesOfInterest(coordinates, coordinateList.last(), coordinateList.first()))) linesCrossed++
        return linesCrossed % 2 != 0
    }

    /**
     * Checks if target location from [v] is on the line segment described in [v]
     */
    private fun isOnEdge(v : ValuesOfInterest) : Boolean {
        //Horizontal
        if (v.rise == 0.0) return v.yt == v.ya && !v.targetLeftOfSegment && !v.targetRightOfSegment
        //Vertical
        if (v.run == 0.0) return v.xt == v.xa && !v.targetAboveSegment && !v.targetBelowSegment
        //Sloped
        return v.intersectionX == v.xt
    }

    /**
     * Checks if a ray from target location in [v] projected infinitely to the right ever crosses
     * line segment described in [v]
     */
    private fun linesCross(v : ValuesOfInterest): Boolean{
        //Crosses horizontal? We count horizontal lines as uncrossed, since they are parallel.
        if (v.rise == 0.0) return false

        //Crosses vertical?
        if (v.run == 0.0) return v.targetLeftOfSegment && !v.targetAboveSegment && !v.targetBelowSegment

        //Crosses sloped? Will cross if intersectionX is on line segment, and coordinate isn't right of both points of line segment
        return !(v.intersectionX > v.xa && v.intersectionX > v.xb)
                && !(v.intersectionX < v.xa && v.intersectionX < v.xb)
                && !v.targetRightOfSegment
        }
}