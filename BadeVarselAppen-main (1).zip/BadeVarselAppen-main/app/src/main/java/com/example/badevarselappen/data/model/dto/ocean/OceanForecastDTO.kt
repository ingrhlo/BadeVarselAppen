package com.example.badevarselappen.data.model.dto.ocean

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName

/**
 * DTOs used by OceanForecast
 * Used to parse data from OceanForecast api from MET.
 */
@Serializable
data class OceanForecastDTO (
    val properties: Properties,

    )

@Serializable
data class Properties(
    val meta: MetaDTO,
    val timeseries: List<TimeSerie>
)

@Serializable
data class MetaDTO(
    @SerialName("updated_at")
    val updatedAt: String,
    val units: UnitsDTO,
)

@Serializable
data class UnitsDTO(
    @SerialName("sea_surface_wave_height")
    val seaSurfaceWaveHeight: String,
    @SerialName("sea_water_temperature")
    val seaWaterTemperature: String,
    @SerialName("sea_water_speed")
    val seaWaterSpeed: String
)

@Serializable
data class TimeSerie (
    val time : String?,
    val data : Instant
)



@Serializable
data class Instant (
    val instant: Details
)



@Serializable
data class Details (
    val details: Sea
)


@Serializable
data class Sea(
    @SerialName("sea_surface_wave_height")
    val seaSurfaceWaveHeight: Double?,
    @SerialName("sea_water_temperature")
    val seaWaterTemperature: Double?,
    @SerialName("sea_water_speed")
    val seaWaterSpeed: Double?
)