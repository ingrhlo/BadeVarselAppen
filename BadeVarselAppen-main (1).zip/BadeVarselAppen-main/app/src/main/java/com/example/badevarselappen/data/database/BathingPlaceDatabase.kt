package com.example.badevarselappen.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [FavoriteBathingPlaceEntity::class],
    version = 1,
    exportSchema = false
)
/**
 * Abstract class used to build [BathingPlaceDatabase], an database holding [FavoriteBathingPlaceEntity]
 */
abstract class BathingPlaceDatabase : RoomDatabase(){


    abstract val favoriteBathingPlaceDAO : FavoriteBathingPlaceDAO

    companion object{
        @Volatile private var instance : BathingPlaceDatabase? = null
        private const val DATABASE_NAME = "favorites_database"

        /**
         * Gets singleton instance of [BathingPlaceDatabase]
         *
         * @param context the context of application.
         * @return always the same instance of [BathingPlaceDatabase]
         */
        fun getInstance(context: Context) : BathingPlaceDatabase {
            return instance ?: synchronized(this){
                instance ?: buildDatabase(context).also { instance = it }
            }
        }

        private fun buildDatabase(context : Context) : BathingPlaceDatabase {
            return Room.databaseBuilder(
                context = context.applicationContext,
                klass = BathingPlaceDatabase::class.java,
                name = DATABASE_NAME
            )
                .build()
        }
    }
}