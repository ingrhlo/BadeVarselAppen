package com.example.badevarselappen.data.model

/**
 * Simple wrapper class to hold a data measurement and its accompanying unit.
 *
 * @param T The type of the value of the measurement. Most often Double or Int
 * @param value The value of the data measurement
 * @param unit The unit of the data measurement
 */
class Measurement<T>(
    val value : T,
    val unit : String
) {
    override fun toString(): String {
        return "$value $unit"
    }
}