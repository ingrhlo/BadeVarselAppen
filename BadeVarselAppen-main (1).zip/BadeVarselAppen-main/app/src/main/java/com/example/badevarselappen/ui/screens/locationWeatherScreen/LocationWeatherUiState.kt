package com.example.badevarselappen.ui.screens.locationWeatherScreen

import androidx.annotation.StringRes

/**
 * The UiState for an [LocationWeatherScreen]
 */
sealed class LocationWeatherUiState {
    /**
     * [Success] objects holds the information collected from the repository.
     *
     * @param locationName name of bathingplace
     * @param shownName name shown to user during editing of name
     * @param locationIsFavorite [Boolean] that signifies whether or not the bathingplace is saved
     * as favorite.
     * @param showKeyboard decides if keyboard is shown or not
     * @param favoritesOption string resource for what the option to add to favorites should say.
     * @param alerts is a list of MetAlerts at the bathingplace, if any exists
     * @param forecastDetails details to be presented in screen
     */
    data class Success(
        val locationName: String,
        val shownName : String = locationName,
        val locationIsFavorite: Boolean,
        val showKeyboard : Boolean = false,
        @StringRes val favoritesOption : Int,
        val alerts: List<PresentableMetAlert>? = null,
        val forecastDetails : PresentableForecast
    ) : LocationWeatherUiState()

    /**
     * [Error] is the loading state when data collection failed.
     *
     * @param errorMessage the resource that holds the [errorMessage]
     */
    data class Error(
        @StringRes val errorMessage : Int
    ) : LocationWeatherUiState()

    /**
     * [Loading] is the loading state when data is being collected.
     *
     * @param loadingMessage the resource that holds the [loadingMessage]
     */
    data class Loading(
        @StringRes val loadingMessage : Int
    ) : LocationWeatherUiState()
}
