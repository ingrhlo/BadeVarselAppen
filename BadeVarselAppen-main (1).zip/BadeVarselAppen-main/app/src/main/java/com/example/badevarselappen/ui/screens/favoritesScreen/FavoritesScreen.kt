package com.example.badevarselappen.ui.screens.favoritesScreen

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.example.badevarselappen.R
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.ui.common.LocationList
import com.example.badevarselappen.ui.common.LoadingScreen
import com.example.badevarselappen.ui.navigation.topNavigation.TopNavigationBar

/**
 * The screen to show favorites.
 *
 * @param modifier
 * @param viewmodel
 * @param onNavToWeatherScreen action to navigate to screen showing the weather
 * @param bottomNavigationBar the apps navigation at the bottom bar
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    modifier: Modifier = Modifier,
    viewmodel: FavoritesViewmodel,
    onNavToWeatherScreen : (Coordinates) -> Unit,
    bottomNavigationBar : @Composable () -> Unit
) {
    val uiState by viewmodel.uiState.collectAsState()
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {TopNavigationBar(title = stringResource(R.string.FavoritesTitle))},
        bottomBar = bottomNavigationBar
    ) {paddingValues ->
        when(uiState){
            is FavoritesUiState.HasData -> LocationList(
                modifier = modifier.padding(paddingValues),
                bathingPlaceList = (uiState as FavoritesUiState.HasData).favoriteBathingPlaces,
                onNavToWeatherScreen = onNavToWeatherScreen,
            )
            is FavoritesUiState.LoadingData -> LoadingScreen(
                modifier =modifier.padding(paddingValues),
                loadingMessage = stringResource((uiState as FavoritesUiState.LoadingData).loadingMessage)
            )
        }
    }



}
