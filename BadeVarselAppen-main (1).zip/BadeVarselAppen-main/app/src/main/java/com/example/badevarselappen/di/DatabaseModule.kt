package com.example.badevarselappen.di


import android.content.Context
import com.example.badevarselappen.data.database.BathingPlaceDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
/**
 * Object that lets dagger-hilt provide injected constructors with [BathingPlaceDatabase]
 */
object DatabaseModule {
    @Singleton
    @Provides
    fun provideDatabaseInstance(
       @ApplicationContext context: Context
    ) : BathingPlaceDatabase {
        return BathingPlaceDatabase.getInstance(context)
    }
}