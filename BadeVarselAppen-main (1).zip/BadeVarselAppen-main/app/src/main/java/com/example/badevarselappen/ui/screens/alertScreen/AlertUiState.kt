package com.example.badevarselappen.ui.screens.alertScreen

import com.example.badevarselappen.ui.screens.locationWeatherScreen.PresentableMetAlert

/**
 * The uistate of the [AlertScreen].
 *
 * @param alert the [PresentableMetAlert] to be shown
 */
data class AlertUiState(
    val alert : PresentableMetAlert
)