package com.example.badevarselappen.ui.screens.locationWeatherScreen

import androidx.annotation.DrawableRes
import com.example.badevarselappen.R

/**
 * Enum class to hold information about all different types of warning icons
 *
 * @param eventType type of event,
 * @param level event danger level. Yellow, orange or red.
 * @param icon the resource for the icon.
 */
enum class AlertSymbol(
    val eventType : String,
    val level : String,
    @DrawableRes val icon : Int,
) {
    BlowingSnowYellow("blowingSnow","yellow", R.drawable.icon_warning_drivingconditions_yellow),
    BlowingSnowOrange("blowingSnow", "orange", R.drawable.icon_warning_drivingconditions_orange),
    BlowingSnowRed("blowingSnow", "red", R.drawable.icon_warning_drivingconditions_red),
    ForestFireYellow("forestFire", "yellow", R.drawable.icon_warning_forestfire_yellow),
    ForestFireOrange("forestFire","orange", R.drawable.icon_warning_forestfire_orange),
    ForestFireRed("forestFire","red", R.drawable.icon_warning_forestfire_red),
    GaleYellow("gale","yellow", R.drawable.icon_warning_wind_yellow),
    GaleOrange("gale","orange", R.drawable.icon_warning_wind_orange),
    GaleRed("gale","red", R.drawable.icon_warning_wind_red),
    IceYellow("ice", "yellow", R.drawable.icon_warning_drivingconditions_yellow),
    IceOrange("ice", "orange", R.drawable.icon_warning_drivingconditions_orange),
    IceRed("ice", "red", R.drawable.icon_warning_drivingconditions_red),
    IcingYellow("icing", "yellow", R.drawable.icon_warning_ice_yellow),
    IcingOrange("icing", "orange", R.drawable.icon_warning_ice_orange),
    IcingRed("icing","red", R.drawable.icon_warning_ice_red),
    LightningYellow("lightning", "yellow", R.drawable.icon_warning_lightning_yellow),
    LightningOrange("lightning", "orange", R.drawable.icon_warning_lightning_orange),
    LightningRed("lightning", "red", R.drawable.icon_warning_lightning_red),
    PolarLowYellow("polarLow","yellow", R.drawable.icon_warning_polarlow_yellow),
    PolarLowOrange("polarLow","orange", R.drawable.icon_warning_polarlow_orange),
    PolarLowRed("polarLow","red", R.drawable.icon_warning_lightning_red),
    RainYellow("rain", "yellow", R.drawable.icon_warning_rain_yellow),
    RainOrange("rain", "orange", R.drawable.icon_warning_rain_orange),
    RainRed("rain","red", R.drawable.icon_warning_rain_red),
    RainFloodYellow("rainFlood","yellow", R.drawable.icon_warning_rainflood_yellow),
    RainFloodOrange("rainFlood", "orange", R.drawable.icon_warning_rainflood_orange),
    RainFloodRed("rainFlood", "red", R.drawable.icon_warning_rainflood_red),
    SnowYellow("snow","yellow",R.drawable.icon_warning_snow_yellow),
    SnowOrange("snow", "orange", R.drawable.icon_warning_snow_orange),
    SnowRed("snow", "red", R.drawable.icon_warning_snow_red),
    StormSurgeYellow("stormSurge", "yellow", R.drawable.icon_warning_stormsurge_yellow),
    StormSurgeOrange("stormSurge", "orange", R.drawable.icon_warning_stormsurge_orange),
    StormSurgeRed("stormSurge", "red", R.drawable.icon_warning_stormsurge_red),
    WindYellow("wind", "yellow", R.drawable.icon_warning_wind_yellow),
    WindOrange("wind", "orange", R.drawable.icon_warning_wind_orange),
    WindRed("wind", "red", R.drawable.icon_warning_wind_red),
    UvRadiationYellow("uvRadiation", "yellow", R.drawable.icon_warning_generic_yellow),
    UvRadiationOrange("uvRadiation", "orange", R.drawable.icon_warning_generic_orange),
    UvRadiationRed("uvRadiation", "red", R.drawable.icon_warning_generic_red),
}