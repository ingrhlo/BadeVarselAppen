package com.example.badevarselappen.data.model.weatherdata
/**
 * Dataclass that contains bathing-relevant data from a single alert from the MetAlert API.
 *
 * @param consequences The consequence of the alert. Will often be connected to the content of the instruction variable.
 * @param description Description of the alert in more detail
 * @param event The type of event the alert is about
 * @param eventAwarenessName Name of awareness, consists of severity + certainty + event
 * @param geographicDomain Type of area the alert is relevant to: marine or land.
 * @param instruction Recommended action
 * @param severity Severity of event
 * @param title Title of alert
 * @param type Type of alert: Alert, Update or Cancel
 * @param awarenessLevel awarenessLevel, used to indicate color of warning symbol. Is yellow, orange
 * or red
 */

data class MetAlert (
    val consequences: String?,
    val description: String,
    val event: String,
    val eventAwarenessName: String,
    val geographicDomain: String,
    val instruction: String,
    val severity: String,
    val title: String,
    val type: String,
    val awarenessLevel : String
)