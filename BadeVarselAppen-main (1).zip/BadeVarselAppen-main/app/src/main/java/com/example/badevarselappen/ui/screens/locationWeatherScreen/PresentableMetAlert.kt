package com.example.badevarselappen.ui.screens.locationWeatherScreen

import android.os.Parcelable
import androidx.annotation.DrawableRes
import kotlinx.parcelize.Parcelize

/**
 * data class for making objects to ease presentation of metalerts data.
 *
 * @param eventName the name of the event in the alert
 * @param description description of the alert.
 * @param consequences list of consequences, if any, of the alert
 * @param instructions list of instructions for reader
 * @param icon drawable resourceId to get the icon that represents this alert.
 */
@Parcelize
data class PresentableMetAlert(
    val eventName : String,
    val description : String,
    val consequences : List<String>?,
    val instructions : List<String>,
    @DrawableRes val icon : Int
) : Parcelable