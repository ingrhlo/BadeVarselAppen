package com.example.badevarselappen.ui.navigation.bottomNavigation

import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Simple data class to hold information about items in an bottom navigation bar
 *
 * @param name label that will be under icon
 * @param route which screen it will navigate to
 * @param icon the icon of seen in the navigation bar
 */
data class BottomNavItem(
    val name : String,
    val route : String,
    val icon : ImageVector
)
