package com.example.badevarselappen.ui.screens.locationWeatherScreen

/**
 * A simple singleton mapping of all the [AlertSymbols]
 */
object AlertSymbols {
    val symbols = AlertSymbol.values().associateBy { "${it.eventType};${it.level}" }
}