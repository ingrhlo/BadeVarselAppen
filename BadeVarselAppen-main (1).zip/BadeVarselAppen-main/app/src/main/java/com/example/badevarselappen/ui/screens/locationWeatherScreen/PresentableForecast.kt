package com.example.badevarselappen.ui.screens.locationWeatherScreen

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * A dataclass to ease the use of the data for the [LocationWeatherScreen]
 *
 * @param airWaterHeader header that says whether there is only weather, or weather and water temperature
 * @param airWaterNowTemp current weather (and if it exists) water temperature
 * @param nextHourIcon icon resource id for current weather
 * @param nextHourText the description of the weather for the next hour
 * @param next12HourIcon icon resource id for weather in about 12 hours
 * @param forecastData extra forecast data to be presented in the [LocationWeatherScreen]
 */
data class PresentableForecast(
    val airWaterHeader : String,
    val airWaterNowTemp : String,
    @DrawableRes val nextHourIcon : Int,
    @StringRes val nextHourText : Int,
    @DrawableRes val next12HourIcon: Int,
    val forecastData : List<PresentableForeCastData>
)





