package com.example.badevarselappen.data.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import com.example.badevarselappen.data.model.BathingPlace
import com.example.badevarselappen.data.model.Coordinates


/**
 * object that are entities in [BathingPlaceDatabase]
 *
 * @param name name of [BathingPlace]
 * @param latitude latitude in [BathingPlace] [Coordinates]
 * @param longitude longitude in [BathingPlace] [Coordinates]
 */
@Entity(
    tableName = FavoriteBathingPlaceTables.FAVORITE_BATHING_PLACES,
    primaryKeys = [FavoriteBathingPlaceTables.COLUMN_LATITUDE
        , FavoriteBathingPlaceTables.COLUMN_LONGITUDE]
    )
data class FavoriteBathingPlaceEntity(
    val name : String,
    @ColumnInfo(FavoriteBathingPlaceTables.COLUMN_LATITUDE) val latitude : String,
    @ColumnInfo(FavoriteBathingPlaceTables.COLUMN_LONGITUDE) val longitude : String
)

/**
 * Method to change an [BathingPlace] into an [FavoriteBathingPlaceEntity]
 */
fun BathingPlace.bathingPlaceToDatabaseEntity() : FavoriteBathingPlaceEntity {
    return FavoriteBathingPlaceEntity(
        name = this.name,
        latitude = this.coordinates.latitude,
        longitude = this.coordinates.longitude
    )
}

/**
 * Method to change an [FavoriteBathingPlaceEntity] into an [BathingPlace]
 */
fun FavoriteBathingPlaceEntity.databaseEntityAsBathingPlace() : BathingPlace {
    return BathingPlace(
        name = this.name,
        coordinates = Coordinates(
            latitude = this.latitude,
            longitude = this.longitude
        ),
    )
}