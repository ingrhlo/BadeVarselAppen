package com.example.badevarselappen.data.model.weatherdata

import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.Measurement

/**
 * Object that holds information gathered from NowCast API
 *
 * @param fetchedTimeStamp the time in UTC that data was fetched from server, as string
 * @param coordinates the coordinates for which the data is relevant to
 * @param airTemperature current measured air temperature
 * @param precipitationRate current measured precipitation rate
 * @param relativeHumidity current measured relative humidity
 * @param windSpeed current measured wind speed
 * @param windSpeedOfGust current average measured wind speed of gust of winds
 * @param symbolCodeNextHour string that will say which icon to use to represent the weather the
 * next hour
 * @param precipitationAmountNextHour expected precipitation amount the next hour
 */
data class NowCast(
    val fetchedTimeStamp: String,
    val coordinates : Coordinates,
    val airTemperature : Measurement<Double>?,
    val precipitationRate : Measurement<Double>?,
    val relativeHumidity : Measurement<Double>?,
    val windSpeed : Measurement<Double>?,
    val windSpeedOfGust : Measurement<Double>?,
    val symbolCodeNextHour : String?,
    val precipitationAmountNextHour : Measurement<Double>?,
    )
