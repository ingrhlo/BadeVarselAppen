package com.example.badevarselappen.ui.common

import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.TextUnit

/**
 * A textfield that can submit data by using enter at keyboard. That functionality is mostly useful
 * for developers trying out ui on pc.
 *
 * @param modifier
 * @param value the start value in the textfield. Default is empty.
 * @param keyboardType type of visual keyboard interface. Ascii is default
 * @param onValueChange action that happens when value in field changes
 * @param onDone action that happens when keyboard interface clicks "done", or real keyboard presses
 * enter
 * @param enabled 
 * @param fontSize
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun KeyboardFriendlyBasicTextField(
    modifier: Modifier = Modifier,
    value : String = "",
    keyboardType: KeyboardType = KeyboardType.Ascii,
    onValueChange : (String) -> Unit,
    onDone : () -> Unit,
    enabled : Boolean = true,
    fontSize : TextUnit = TextStyle.Default.fontSize
){
    BasicTextField(
        enabled = enabled,
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            imeAction = ImeAction.Done,
            keyboardType = keyboardType
        ),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        modifier = modifier.onKeyEvent {
            if (it.key == Key.Enter) {
                onDone()
                return@onKeyEvent true
            }
            false
        },
        textStyle = TextStyle.Default.copy(fontSize = fontSize)
    )
}



