package com.example.badevarselappen.ui.screens.locationWeatherScreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.badevarselappen.R
import com.example.badevarselappen.ui.common.*
import com.example.badevarselappen.ui.navigation.topNavigation.MenuOption
import com.example.badevarselappen.ui.navigation.topNavigation.TopAppMenu
import com.example.badevarselappen.ui.navigation.topNavigation.TopNavigationBar


val textStyleBig = TextStyle(
    fontSize = 50.sp,
    fontWeight = FontWeight.Bold,
    color = Color.DarkGray
)

val textStyleMedium = TextStyle(
    fontSize = 25.sp,
    color = Color.DarkGray
)

val textStyleSmall = TextStyle(
    fontSize = 18.sp,
    color = Color.DarkGray
)

/**
 * Success screen, that shows the weather bathing forecast.
 *
 * @param modifier moidier for the screen.
 * @param uiState contains [LocationWeatherUiState.Success] which contains weather information.
 * @param onNavControlBackButton action to navigate back
 * @param navigateToAlert action to navigate to a screen showing the [PresentableMetAlert]
 * @param viewModel
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WeatherScreen (
    modifier: Modifier = Modifier,
    uiState : LocationWeatherUiState.Success,
    viewModel: LocationWeatherViewmodel,
    onNavControlBackButton: () -> Unit,
    navigateToAlert: (PresentableMetAlert) -> Unit
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            WeatherTopBar(
                uiState = uiState,
                viewModel = viewModel,
                onNavControlBackButton = onNavControlBackButton
            )
        },
    ){contentPadding ->
        LazyColumn(modifier = modifier
            .fillMaxSize()
            .padding(contentPadding)
            .padding(start = 12.dp)
            .padding(top = 10.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                AlertRow(
                    modifier = Modifier.fillMaxWidth(),
                    alerts = uiState.alerts,
                    navigateToAlert = navigateToAlert
                )
            }
            item { MainWeatherInfo(uiState.forecastDetails) }
            items( items = uiState.forecastDetails.forecastData) { ExtraForeCastData(it) }
        }
    }
}

/**
 * The main weather info, showing temperatures and icons. It is supposed to be in the lazy column.
 */
@Composable
private fun MainWeatherInfo(
    forecastDetails : PresentableForecast,
) {
    val paddingModifier = Modifier.padding(start = 6.dp)
    Text(
        text = forecastDetails.airWaterHeader,
        style = textStyleSmall,
        modifier = paddingModifier
    )
    Text(
        text = forecastDetails.airWaterNowTemp,
        style = textStyleBig,
        modifier = paddingModifier
    )
    Row {
        Image(
            painter = painterResource(forecastDetails.nextHourIcon),
            contentDescription = null
        )
        Text(
            text = stringResource(forecastDetails.nextHourText),
            style = textStyleSmall,
            modifier = Modifier
                .padding(
                    top = 25.dp,
                    start = 10.dp
                )
        )
    }
    Row {
        Text(
            text = stringResource(R.string.next12HoursHeader),
            modifier = Modifier.padding(top = 25.dp, start = 7.dp)
        )
        Image(
            painter = painterResource(forecastDetails.next12HourIcon),
            contentDescription = null
        )
    }
}

/**
 * All extra forecast lines that might not be there, for example precipitation amount.
 */
@Composable
fun ExtraForeCastData(foreCastData: PresentableForeCastData){
    val paddingModifier = Modifier.padding(start = 6.dp)
    Text(
        text= stringResource(foreCastData.header),
        style = textStyleMedium,
        modifier = paddingModifier
    )
    Text(
        text= foreCastData.data,
        style = textStyleBig,
        modifier = paddingModifier
    )
}

/**
 * Composable function that shows SimpleTextScreen or WeatherScreen depending on uiState.
 *
 * @param viewModel the viewmodel that has the uiState
 * @param onNavControlBackButton used to navigate back, when button is clicked
 * @param onNavControlBackButton action to navigate back
 * @param navigateToAlert action to navigate to a screen showing the [PresentableMetAlert]
 */
@Composable
fun LocationWeatherScreen(
    modifier: Modifier = Modifier,
    viewModel: LocationWeatherViewmodel,
    onNavControlBackButton: () -> Unit,
    navigateToAlert : (PresentableMetAlert) -> Unit,
) {

    val uiState by viewModel.uiState.collectAsState()

    when (uiState) {
        is LocationWeatherUiState.Success -> WeatherScreen(
            modifier = modifier,
            uiState = uiState as LocationWeatherUiState.Success,
            onNavControlBackButton = onNavControlBackButton,
            navigateToAlert = navigateToAlert,
            viewModel = viewModel
        )
        else -> NotWeatherScreen(
            modifier = modifier,
            uiState = uiState,
            onNavControlBackButton = onNavControlBackButton,
            retryAction = {viewModel.updateWeatherReport()}
        )
    }
}

/**
 * A screen that is shown during loading, or errors.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotWeatherScreen(
    modifier : Modifier = Modifier,
    uiState : LocationWeatherUiState,
    onNavControlBackButton : () -> Unit,
    retryAction : () -> Unit
){
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {TopNavigationBar(
            title = "",
            navigateUp = onNavControlBackButton
        )},
    ) { contentPadding ->
        when (uiState) {
            is LocationWeatherUiState.Loading -> LoadingScreen(
                modifier = modifier.padding(contentPadding),
                loadingMessage = stringResource(uiState.loadingMessage)
            )
            is LocationWeatherUiState.Error -> ErrorScreen(
                modifier = modifier.padding(contentPadding),
                errorMessage = stringResource(uiState.errorMessage),
                retryAction = retryAction
            )
            else -> {} //Should not happen, when used correctly
        }
    }
}


/**
 * A topappBar that can navigate back, has an overflow menu, and can edit names of bathing places,
 * if it is a favorite.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun WeatherTopBar(
    modifier: Modifier = Modifier,
    viewModel: LocationWeatherViewmodel,
    uiState: LocationWeatherUiState.Success,
    onNavControlBackButton: () -> Unit
){
    val kc = LocalSoftwareKeyboardController.current
    val focusRequester = remember { FocusRequester() }
    val menuOptions = listOf(MenuOption(
        text = stringResource(uiState.favoritesOption),
        action = {viewModel.addOrRemoveFromFavorites()}
    ))
    val onClick : () -> Unit = {
        if(!uiState.showKeyboard) {
            focusRequester.requestFocus()
            kc?.show()
        }
        else {
            viewModel.submitName()
            kc?.hide()
        }
        viewModel.upDateKeyboardState()
    }

    val onDone : () -> Unit = {
        viewModel.submitName()
        kc?.hide()
    }

    SmallTopAppBar(
        modifier = modifier
            .drawBehind {
                drawLine(
                    color = Color.LightGray,
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 4.dp.toPx()
                )},
        navigationIcon = { NavigateUpButton(navigateUp = onNavControlBackButton) },
        actions = {if (uiState.locationIsFavorite) IconButton(onClick = onClick){
            Icon(
                modifier = Modifier.size(25.dp),
                imageVector = ImageVector.vectorResource(R.drawable.pencil),
                contentDescription = stringResource(R.string.LocationWeatherChangeNameContentDescription)
            )
        }
            TopAppMenu(menuOptions = menuOptions)
        },
        title = {KeyboardFriendlyBasicTextField(
            modifier = Modifier.focusRequester(focusRequester),
            value = uiState.shownName,
            onValueChange = {viewModel.editShownName(it)},
            onDone = onDone,
            enabled = uiState.locationIsFavorite,
            fontSize = 30.sp
        )}
    )
}

@Composable
private fun AlertRow(
    modifier: Modifier = Modifier,
    alerts : List<PresentableMetAlert>?,
    navigateToAlert: (PresentableMetAlert) -> Unit
){
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ){
        alerts?.forEach {alert ->
            AlertIconButtonWithTitleUnder(
                alert = alert,
                navigateToAlert = navigateToAlert ,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )
        }
    }
}
