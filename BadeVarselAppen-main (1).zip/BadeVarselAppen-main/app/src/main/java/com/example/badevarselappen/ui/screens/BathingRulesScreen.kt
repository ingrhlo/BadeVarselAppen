package com.example.badevarselappen.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.badevarselappen.R
import com.example.badevarselappen.ui.navigation.topNavigation.TopNavigationBar

/**
 * Bathing Rules screen, that shows the nine bathing rules
 *
 * @param modifier moidier for the screen.
 * @param onNavControllBackButton used to navigate back, when button is clicked.
 * @param bottomNavigationBar the apps navigation at the bottom bar
 */

val textStyleMedium = TextStyle(
    fontSize = 25.sp,
    color = Color.DarkGray
)

val textStyleSmall = TextStyle(
    fontSize = 18.sp,
    color = Color.DarkGray
)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BathingRulesScreen(modifier: Modifier = Modifier,
                       onNavControllBackButton: () -> Unit,
                       bottomNavigationBar : @Composable () -> Unit
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = bottomNavigationBar,
        topBar = { TopNavigationBar(title = stringResource(R.string.BathingRules)) }

    ) { contentPadding ->
        Card(
            modifier = Modifier
                .padding(contentPadding)
                .padding(15.dp)
        ) {
            LazyColumn() {
                item {
                    Text(
                        text = stringResource(R.string.Nine_Bathing_Rules),
                        style = textStyleMedium,
                        modifier = Modifier.padding(6.dp)
                    )
                    Spacer(Modifier.size(20.dp))
                    Text(
                        text = stringResource(R.string.Rule_One),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_Two),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_Three),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_Four),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_Five),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_Six),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_Seven),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_eight),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Text(
                        text = stringResource(R.string.Rule_Nine),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                    Spacer(Modifier.size(20.dp))
                    Text(
                        text = stringResource(R.string.Source),
                        style = textStyleSmall,
                        modifier = Modifier.padding(6.dp)
                    )
                }
            }
        }
    }
}

