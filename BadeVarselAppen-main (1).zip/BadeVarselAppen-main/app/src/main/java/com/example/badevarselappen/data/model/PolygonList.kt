package com.example.badevarselappen.data.model

/**
* List of Polygons
 *
 * @constructor Creates a list of Polygons from the provided List<List<List<Double>>>
 *
*/
class PolygonList (polygonDataList:List<List<List<Double>>>){
    private val polygonList: List<Polygon> = polygonDataList.let {
        val tmpList: MutableList<Polygon> = mutableListOf()
        for (polygonData in it) tmpList.add(Polygon(polygonData))
        return@let tmpList
    }

    fun covers(coordinates: Coordinates): Boolean{
        /**
         * Checks if the coordinates are within any of the Polygons in the polygon-list
         * @return whether or not the provided coordinates are covered by the PolygonList
         */
        for (polygon in polygonList) {
            if (polygon.covers(coordinates)) return true
        }
        return false
    }
}
