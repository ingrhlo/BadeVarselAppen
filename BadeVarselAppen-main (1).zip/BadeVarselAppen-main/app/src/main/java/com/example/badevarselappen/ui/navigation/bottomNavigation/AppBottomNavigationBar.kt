package com.example.badevarselappen.ui.navigation.bottomNavigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.navigation.NavController
import com.example.badevarselappen.R
import com.example.badevarselappen.ui.navigation.AppDestinations

/**
 * The apps standard bottom navigation bar
 *
 * @param modifier
 * @param navController that controls navigation in app.
 */
@Composable
fun AppBottomNavigationBar(
    modifier: Modifier = Modifier,
    navController: NavController
) {
    val bottomNavItems = listOf<BottomNavItem>(
        BottomNavItem(
            name = stringResource(R.string.MapTitle),
            route = AppDestinations.MAPS_ROUTE,
            icon = ImageVector.vectorResource(R.drawable.maps)
        ),
        BottomNavItem(
            name = stringResource(R.string.LocationListNavigationName),
            route = AppDestinations.LOCATION_LIST_ROUTE,
            icon = ImageVector.vectorResource(R.drawable.list)
        ),
        BottomNavItem(
            name = stringResource(R.string.FavoritesTitle),
            route = AppDestinations.FAVORITES_ROUTE,
            icon = ImageVector.vectorResource(R.drawable.heart)
        ),
        BottomNavItem(
            name = stringResource(R.string.BathingRulesBottomBar),
            route = AppDestinations.RULES_ROUTE,
            icon =  ImageVector.vectorResource(R.drawable.baseline_menu_book_24)
        )

    )

    BottomNavigationBar(
        modifier = modifier,
        bottomNavItems = bottomNavItems,
        navController = navController
    )
}