package com.example.badevarselappen.data.database

/**
 * Object holding table names and column names of [BathingPlaceDatabase]
 */
object FavoriteBathingPlaceTables {
    const val FAVORITE_BATHING_PLACES = "favorite_bathing_places"
    const val COLUMN_LATITUDE = "latitude"
    const val COLUMN_LONGITUDE = "longitude"
}
