package com.example.badevarselappen.data.model.dto.weather.locationforecast
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * DTOs used by LocationForecast and WeatherForecast
 * Used to parse data from Locationforecast api from MET.
 */
@Serializable
data class LocationForecastDTO(
    val properties : PropertiesDTO
)

@Serializable
data class PropertiesDTO(
    val meta: MetadataDTO,
    val timeseries : List<ForecastFromTimeDTO>,
)

@Serializable
data class  MetadataDTO(
    @SerialName("updated_at")
    val updatedAt : String, //All time stamps are in UTC
    val units : UnitsDTO,
)

@Serializable
data class ForecastFromTimeDTO(//Needs better name.
    val time : String,
    val data : ForecastDTO
)

@Serializable
data class UnitsDTO(
    @SerialName("air_temperature")
    val airTemperature : String,
    @SerialName("cloud_area_fraction")
    val cloudiness : String,
    @SerialName("fog_area_fraction")
    val fog : String,
    @SerialName("relative_humidity")
    val relativeHumidity : String,
    @SerialName("ultraviolet_index_clear_sky")
    val ultravioletIndex : String,
    @SerialName("wind_speed")
    val windSpeed : String,
    @SerialName("probability_of_precipitation")
    val probabilityOfPrecipitation : String
)

@Serializable
data class ForecastDTO(
    val instant : InstantDTO,
    @SerialName("next_12_hours")
    val next12Hours : Next12HourDTO? = null
    // Can choose between next 1, 6 nd 12 hours
)
@Serializable
data class InstantDTO(
    val details : DetailsDTO
)

@Serializable
data class DetailsDTO(
    @SerialName("air_temperature")
    val airTemperature : Double? = null,
    @SerialName("cloud_area_fraction")
    val cloudiness : Double? = null,
    @SerialName("fog_area_fraction")
    val fog : Double? = null,
    @SerialName("relative_humidity")
    val relativeHumidity : Double? = null,
    @SerialName("ultraviolet_index_clear_sky")
    val ultravioletIndex : Double? = null, //ultraviolet index for cloud free conditions, 0 (low) to 11+ (extreme)
    @SerialName("wind_speed")
    val windSpeed : Double? = null,
    @SerialName("probability_of_precipitation")
    val probabilityOfPrecipitation : Double? = null
)

@Serializable
data class Next12HourDTO(
    val summary : SummaryDTO,
    val details: DetailsDTO
)

@Serializable
data class SummaryDTO(
    @SerialName("symbol_code")
    val symbolCode : String,
    @SerialName("symbol_confidence")
    val symbolConfidence : String
)