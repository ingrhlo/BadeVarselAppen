package com.example.badevarselappen.data.model.weatherdata

import com.example.badevarselappen.data.model.Measurement

/**
 * Object that holds main weather information from the Loctaionforecast API
 *
 * @param time the time the data belongs to, as string
 * @param airTemperature measured air temperature
 * @param cloudiness total cloud cover for all heights in percent
 * @param fog amount of surrounding area covered in fog in percent
 * @param relativeHumidity measured relative humidity in percent
 * @param ultravioletIndex ultraviolet index for cloud free conditions, 0 (low) to 11+ (extreme)
 * @param windSpeed measured wind speed, m/s
 * @param probabilityOfPrecipitation12h the chance of precipitation during the next 12 hours in percent
 * @param symbolCode12h string that will say which icon to use to represent the weather for the
 * next 12 hours
 * @param symbolConfidence12h the confidence in the symbol code
 */

data class WeatherForecast(
    val time: String,
    val airTemperature : Measurement<Double>? = null,
    val cloudiness : Measurement<Double>? = null,
    val fog : Measurement<Double>? = null,
    val relativeHumidity : Measurement<Double>? = null,
    val ultravioletIndex : Measurement<Double>? = null,
    val windSpeed : Measurement<Double>? = null,
    val probabilityOfPrecipitation12h : Measurement<Double>? = null, //for next 12 hours
    val symbolCode12h : String, //for next 12 hours
    val symbolConfidence12h : String // for next 12 hours
)