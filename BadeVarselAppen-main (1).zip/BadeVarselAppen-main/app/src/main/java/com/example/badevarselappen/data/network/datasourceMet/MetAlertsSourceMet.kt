package com.example.badevarselappen.data.network.datasourceMet

import com.example.badevarselappen.BuildConfig
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.PolygonList
import com.example.badevarselappen.data.model.convertUTCTimeToLocalTimeZone
import io.ktor.client.engine.cio.*
import io.ktor.client.request.*
import com.example.badevarselappen.data.model.dto.metalerts.FeaturesDTO
import com.example.badevarselappen.data.model.dto.metalerts.MetAlertDTO
import com.example.badevarselappen.data.model.weatherdata.MetAlert
import com.example.badevarselappen.data.model.weatherdata.MetAlerts
import io.ktor.client.call.*
import io.ktor.client.engine.*
import io.ktor.http.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
/**
 * Object to fetch data from MetAlert API
 *
 * @param engine [HttpClientEngine] that can be provided. Default is a CIO engine. Custom engines
 * should mostly be provided when testing the [MetAlertsSourceMet]
 */
class MetAlertsSourceMet(
    engine : HttpClientEngine = CIO.create(),
    private val minutesToLive: Long = 60
) : DataSourceMet<MetAlerts>(engine) {

    private var savedJson: MetAlertDTO? = null
    private var timeStamp: LocalDateTime? = null
    private var eTag: String? = null
    private var lastModified: String? = null

    override fun apiAddress(coordinates: Coordinates) = BuildConfig.metAlerts

    override suspend fun getData(coordinates: Coordinates): MetAlerts? {

        if (timeStamp == null || (LocalDateTime.now().minusMinutes(minutesToLive) > timeStamp) ){
            val httpResponse = client.get(apiAddress(coordinates)) {
                headers {
                    if (eTag != null) append(HttpHeaders.IfNoneMatch,eTag!!)
                    if (lastModified != null) append(HttpHeaders.IfModifiedSince,lastModified!!)
                }
            }

            when (httpResponse.status) {
                HttpStatusCode.NotModified -> {
                    timeStamp = LocalDateTime.now()
                }
                HttpStatusCode.OK -> {
                    savedJson = httpResponse.body()
                    timeStamp = LocalDateTime.now()
                    eTag = httpResponse.headers[HttpHeaders.ETag]
                    lastModified = httpResponse.headers[HttpHeaders.LastModified]
                }
                else -> {
                    return null
                }
            }
        }
        val relevantAlerts: MutableList<MetAlert> = mutableListOf()
        savedJson?.features?.forEach{
            val polygonList = PolygonList(it.geometry.coordinates)
            if (polygonList.covers(coordinates) && timeIntervalIsRelevant(it)) {
                addRelevantAlert(it,relevantAlerts)
            }
        }
        if (relevantAlerts.size == 0) return null
        return MetAlerts(relevantAlerts)
    }

    private fun addRelevantAlert(features: FeaturesDTO, relevantAlerts: MutableList<MetAlert>){
        val alert = MetAlert(
            consequences = features.properties.consequences,
            description = features.properties.description ,
            event = features.properties.event ,
            eventAwarenessName = features.properties.eventAwarenessName,
            geographicDomain = features.properties.geographicDomain,
            instruction = features.properties.instruction,
            severity = features.properties.severity,
            title = features.properties.title,
            type = features.properties.type,
            awarenessLevel = features.properties.awarenessLevel.split("; ")[1]
        )
        relevantAlerts.add(alert)
    }

    private fun timeIntervalIsRelevant(features: FeaturesDTO): Boolean{
        val alertEndingTimeString = features.properties.eventEndingTime ?: features.whenField.interval.last()
        val localAlertEndingTimeString = convertUTCTimeToLocalTimeZone(alertEndingTimeString)
        val lastLocalRelevantAlertTime = LocalDateTime.parse(
            localAlertEndingTimeString,
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss") //It would be best if this was a pattern supplied by TimeConverter
        )
        val now = LocalDateTime.now()
        return now < lastLocalRelevantAlertTime
    }


}