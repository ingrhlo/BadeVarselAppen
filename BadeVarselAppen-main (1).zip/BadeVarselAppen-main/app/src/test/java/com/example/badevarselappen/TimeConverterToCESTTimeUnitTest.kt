package com.example.badevarselappen

import com.example.badevarselappen.data.model.convertUTCTimeToLocalTimeZone
import kotlinx.coroutines.runBlocking
import org.junit.Test

//This only works when we are two hours before UTC timezone. In CEST timezone
class TimeConverterToCESTTimeUnitTest {

    @Test
    fun `convert UTC time to CEST time`() {
        runBlocking {
            assert(convertUTCTimeToLocalTimeZone("2023-04-12T09:14:37Z") == "2023-04-12 11:14:37")
        }
    }

    @Test
    fun `convert UTC time to CEST time when date changes to`() {
        runBlocking {
            assert(convertUTCTimeToLocalTimeZone("2023-04-12T23:14:37Z") == "2023-04-13 01:14:37")
        }
    }
}