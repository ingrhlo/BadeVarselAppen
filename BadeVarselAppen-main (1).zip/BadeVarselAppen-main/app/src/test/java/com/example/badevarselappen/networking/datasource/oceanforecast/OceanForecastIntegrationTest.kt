package com.example.badevarselappen.networking.datasource.oceanforecast

import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.network.datasourceMet.OceanForecastSourceMet
import com.example.badevarselappen.data.model.weatherdata.OceanForecast
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*

class OceanForecastIntegrationTest {
    private val source = OceanForecastSourceMet()

    @Test
    fun `legal coordinates gives OceanForecast`() {
        runBlocking { assert(source.getData(Coordinates("59.9333", "10.7166")) is OceanForecast) }
    }

    @Test
    fun `illegal coordinates return null`() {
        runBlocking { assertNull(source.getData(Coordinates("42.9333", "42.7166"))) }
    }
}