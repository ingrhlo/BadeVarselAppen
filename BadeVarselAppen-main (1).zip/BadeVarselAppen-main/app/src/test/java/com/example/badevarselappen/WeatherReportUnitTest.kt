package com.example.badevarselappen

import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.weatherdata.WeatherReport
import org.junit.Assert
import org.junit.Test

class WeatherReportUnitTest {
    @Test
    fun `Comparing between two different WeatherReports gives 1 and -1`() {
        val first = WeatherReport(Coordinates("0","0"))
        Thread.sleep(1)
        val second = WeatherReport(Coordinates("1","1"))
        Assert.assertFalse(first == second)
        Assert.assertTrue(first < second)
        Assert.assertFalse(second < first)
    }

    @Test
    fun `Comparing with the same WeatherReport gives 0`() {
        val report = WeatherReport(Coordinates("0","0"))
        val copy = report.copy()
        Assert.assertEquals(0, report.compareTo(copy))
    }
}