package com.example.badevarselappen.networking


import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.weatherdata.WeatherReport
import com.example.badevarselappen.data.repository.WeatherReportRepository
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.Assert.*

class WeatherReportRepositoryIntegrationTest {
    private fun assertGotData(weatherReport: WeatherReport){
        assertTrue(weatherReport.oceanForecast != null ||
                weatherReport.locationForecast != null ||
                weatherReport.nowCast != null
        )
    }

    @Test
    fun `WeatherReportRepository with no cacheSize will get two different objects at same coordinates`() {
        val repository = WeatherReportRepository(maxCacheSize = 0)
        runBlocking {
            assertNotEquals(
                repository.getData(Coordinates("1337.0001", "42.0002")),
                repository.getData(Coordinates("1337.0001", "42.0002"))
            )
        }
    }

    @Test
    fun `WeatherReportRepository with a cacheSize will get same objects at same coordinates`() {
        val repository = WeatherReportRepository(maxCacheSize = 1)
        runBlocking {
            assertEquals(
                repository.getData(Coordinates("1337.0001", "42.0002")),
                repository.getData(Coordinates("1337.0001", "42.0002"))
            )
        }
    }

    @Test
    fun `WeatherReportRepository with lifetimeMinutesInCache = 0 and legal coordinates, will return different objects`() {
        val repository = WeatherReportRepository(lifetimeMinutesInCache = 0)
        runBlocking {
            val first = repository.getData(Coordinates("72.37", "40"))
            assertGotData(first)
            assertNotEquals(first, repository.getData(Coordinates("72.37", "40")))
        }
    }

    @Test
    fun `WeatherReportRepository with lifeTimeMinutes gt 0 and legal coordinates, will return same objects`() {
        val repository = WeatherReportRepository()
        runBlocking {
            val first = repository.getData(Coordinates("72.37", "40"))
            assertGotData(first)
            assertEquals(first, repository.getData(Coordinates("72.37", "40")))
        }
    }

    @Test
    fun `Too precise legal coordinates will return same object `() {
        val repository = WeatherReportRepository(decimalCoordinatePrecision = 2)
        runBlocking {
            val first = repository.getData(Coordinates("72.37", "40.20"))
            assertGotData(first)
            assertEquals(
                first,
                repository.getData(Coordinates("72.37444444", "40.2044444"))
            )
            assertEquals(
                first,
                repository.getData(Coordinates("72.369999999", "40.1998989898"))
            )
        }
    }

    @Test
    fun `Not precise enough legal coordinates gets 0-s added, and can return a object in cache`(){
        val repository = WeatherReportRepository(decimalCoordinatePrecision = 5)
        runBlocking {
            val first = repository.getData(Coordinates("72.36000", "40.20000"))
            assertGotData(first)
            assertEquals(
                first,
                repository.getData(Coordinates("72.36", "40.2"))
            )
        }
    }

    @Test
    fun `A repository cannot have decimalCoordinatePrecision lower than 0`(){
        assertThrows(IllegalArgumentException().javaClass){
            WeatherReportRepository(decimalCoordinatePrecision = -1)
        }
    }

    @Test
    fun `A repository works as intended with precision 0`(){
        val repository = WeatherReportRepository(decimalCoordinatePrecision = 0)
        runBlocking {
            val first = repository.getData(Coordinates("72.013", "40.20000"))
            assertGotData(first)
            assertEquals(
                first,
                repository.getData(Coordinates("72.3631", "40.298"))
            )
        }
    }
}