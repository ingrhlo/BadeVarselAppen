package com.example.badevarselappen.networking.datasource.metalerts

import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.network.datasourceMet.MetAlertsSourceMet
import kotlinx.coroutines.runBlocking
import org.junit.Test

import org.junit.Assert.*


class MetAlertsIntegrationTest{
    private val source = MetAlertsSourceMet(minutesToLive = 0)
    @Test
    fun illegal_coordinates_return_null() {

       runBlocking {
           assertNull(source.getData(Coordinates("666","666")))
       }
    }
}