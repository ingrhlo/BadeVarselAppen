package com.example.badevarselappen.networking.datasource.locationforecast

import com.example.badevarselappen.data.network.datasourceMet.LocationForecastSourceMet
import com.example.badevarselappen.data.model.Coordinates
import junit.framework.TestCase.assertNull
import kotlinx.coroutines.runBlocking
import org.junit.Test

class LocationForecastIntegrationTest {
    private val source = LocationForecastSourceMet()

    @Test
    fun fetchData() {
        runBlocking { assert(source.getData(Coordinates("59.90", "10.7"))?.forecastList!!.size > 0) }
        runBlocking { assert(source.getData(Coordinates("59.90", "10.7"))?.forecastList!!.size < 100) }
    }

    @Test
    fun fetchIllegalData() {
        runBlocking { assertNull(source.getData(Coordinates("1000", "1000")))  }
    }

}
