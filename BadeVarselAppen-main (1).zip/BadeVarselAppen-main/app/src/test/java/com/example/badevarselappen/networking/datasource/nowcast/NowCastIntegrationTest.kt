package com.example.badevarselappen.networking.datasource.nowcast

import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.weatherdata.NowCast
import com.example.badevarselappen.data.network.datasourceMet.NowCastSourceMet
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.Assert.*

class NowCastIntegrationTest {
    private val source = NowCastSourceMet()


    @Test
    fun `legal coordinates gives LiveWeather`() {
        runBlocking { assert( source.getData(Coordinates("59.9333", "10.7166")) is NowCast) }
        runBlocking { assert( source.getData(Coordinates("70.3705", "31.0241")) is NowCast) }
        runBlocking { assert( source.getData(Coordinates("72.37", "38.02")) is NowCast) }
    }

    @Test
    fun `illegal coordinates returns null`(){
        runBlocking { assertNull( source.getData(Coordinates("42.9333", "42.7166"))) }
        runBlocking { assertNull( source.getData(Coordinates("1337.9333", "1337.7166"))) }
    }


}