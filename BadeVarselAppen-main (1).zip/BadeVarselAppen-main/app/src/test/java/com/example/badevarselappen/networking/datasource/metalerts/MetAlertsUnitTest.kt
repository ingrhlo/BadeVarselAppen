package com.example.badevarselappen.networking.datasource.metalerts

import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.network.datasourceMet.MetAlertsSourceMet
import io.ktor.http.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class MetAlertsUnitTest {
    private lateinit var multiResponseSource : MetAlertsSourceMet

    @Before
    fun setupNewSource(){
        multiResponseSource = MetAlertsSourceMet(
            minutesToLive = 0,
            engine = MetAlertMockEngines.mockEngineWithMultiAnswers
        )
    }

    @Test
    fun `illegal coordinates return null`() {
        runBlocking {
            assertNull(multiResponseSource.getData(Coordinates("666", "666")))
        }
    }

    @Test
    fun `legal coordinates can return null, if no alerts are at the coordinates`(){
        runBlocking {
            assertNull(multiResponseSource.getData(Coordinates("10", "20")))
        }
    }

    @Test
    fun `legal coordinates with alert will return a non-null object`(){
        runBlocking {
            val actualData = multiResponseSource.getData(Coordinates("65.0","11.5"))
            assertNotNull(actualData)
            assertEquals(actualData!!.metAlerts.first().consequences,"Vegetasjon kan lett antennes og store områder kan bli berørt. ")
        }
    }

    @Test
    fun `Source can handle a 304 response, and return same object as earlier`(){
        runBlocking {
            val actualData1 = multiResponseSource.getData(Coordinates("65.0","11.5"))
            assertNotNull(actualData1)
            assertEquals("Vegetasjon kan lett antennes og store områder kan bli berørt. ",actualData1!!.metAlerts.first().consequences)

            val actualData2 = multiResponseSource.getData(Coordinates("65.0","11.5"))
            assertEquals(actualData1,actualData2)

            val lastCode = MetAlertMockEngines.mockEngineWithMultiAnswers.responseHistory.last().statusCode
            assertEquals(HttpStatusCode.NotModified,lastCode)
        }
    }

    @Test
    fun `Source does not crash when server sends an response that isn't 200 or 304`(){
        val faultySource = MetAlertsSourceMet(engine = MetAlertMockEngines.mockFaultyServerResponse)
        runBlocking {
            assertNull(faultySource.getData(Coordinates("2","2")))
        }
    }

    @Test
    fun `Source does not return outdated alerts`(){
        val outdatedSource = MetAlertsSourceMet(engine = MetAlertMockEngines.mockOutdatedServerResponse)
        runBlocking {
            assertNull(outdatedSource.getData(Coordinates("65.0","11.5")))
        }
    }

    @Test
    fun `Source does not ask for new json file when doing two consequitive requests within minutestolive`(){
        val engine = MetAlertMockEngines.mockOutdatedServerResponse
        val before = engine.responseHistory.size
        val cachingSource = MetAlertsSourceMet(engine = engine, minutesToLive = 60)
        runBlocking {
            cachingSource.getData(Coordinates("0","0"))
            cachingSource.getData(Coordinates("36","37"))
            assertEquals(before +1,engine.requestHistory.size)
        }
    }

    @Test
    fun `Source does  ask for new json file when doing two consequitive requests that has passed minutestolive`(){
        val engine = MetAlertMockEngines.mockOutdatedServerResponse
        val before = engine.responseHistory.size
        val cachingSource = MetAlertsSourceMet(engine = engine, minutesToLive = 0)
        runBlocking {
            cachingSource.getData(Coordinates("0","0"))
            cachingSource.getData(Coordinates("36","37"))
            assertEquals(before + 2,engine.requestHistory.size)
        }
    }
}