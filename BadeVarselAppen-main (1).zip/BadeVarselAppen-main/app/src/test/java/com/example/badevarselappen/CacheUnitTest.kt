package com.example.badevarselappen

import com.example.badevarselappen.data.model.Cache
import org.junit.Assert.*
import org.junit.Test

class CacheUnitTest {
    @Test
    fun `No cacheSize, means nothing is saved`(){
        val cache = Cache<Int,Int>(maxSize = 0)
        cache[0] = 0
        assertNull(cache[0])
    }

    @Test
    fun `Adding element to Cache increases size up to, but not above, cacheSize`(){
        val cache = Cache<Int, Int>(maxSize = 2)
        assertEquals(0, cache.size)
        cache[1] = 1
        assertEquals(1, cache.size)
        cache[2] = 2
        assertEquals(2, cache.size)
        cache[3] = 3
        assertEquals(2, cache.size)
    }

    @Test
    fun `Adding element to Cache yeets the oldest element`(){
        val cache = Cache<Int,Int>(maxSize = 2)
        cache[1] = 1
        cache[2] = 2
        cache[3] = 3
        assertNull(cache[1])
        assertNotNull(cache[2])
        assertNotNull(cache[3])
        cache[4] = 4
        assertNull(cache[2])
    }

    @Test
    fun `Getting element from cache, makes element newest entry`(){
        val cache = Cache<Int,Int>(10)
        val originalOrdering = mutableListOf(0,1,2,3,4,5,6)
        originalOrdering.forEach{ cache[it] = it}
        originalOrdering.reversed().forEach{ cache[it] }
        var last = 10000
        cache.forEach{
            assertTrue(it.value<last)
            last = it.value
        }
    }

    @Test
    fun `Updating element makes element newest entry`(){
        val cache = Cache<Int,Int>(10)
        val originalOrdering = mutableListOf(0,1,2,3,4,5,6)
        originalOrdering.forEach{ cache[it] = it}
        originalOrdering.reversed().forEach{cache[it] = (cache[it] ?: 0)}
        var last = 10000
        cache.forEach{
            assertTrue(it.value<last)
            last = it.value
        }
    }
}