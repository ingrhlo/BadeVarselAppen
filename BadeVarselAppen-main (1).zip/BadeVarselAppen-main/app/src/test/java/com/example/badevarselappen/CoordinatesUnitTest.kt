package com.example.badevarselappen


import com.example.badevarselappen.data.model.Coordinates
import org.junit.Assert.*
import org.junit.Test

class CoordinatesUnitTest {
    private val testCoordinates = Coordinates("50", "25")

    @Test
    fun `Coordinate toString gives a comma delimited string`() {
        assertEquals("50,25,0", testCoordinates.toString())
    }

    @Test
    fun `Two equal coordinates should indeed be equal`() {
        val new = Coordinates("50", "25")
        assertEquals(testCoordinates,new)
    }

    @Test
    fun `Two unequal coordinates should indeed not be equal`() {
        val new = Coordinates("50", "30")
        assertNotEquals(testCoordinates,new)
    }
}