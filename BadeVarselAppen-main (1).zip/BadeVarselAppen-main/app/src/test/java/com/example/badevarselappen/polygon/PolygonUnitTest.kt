package com.example.badevarselappen.polygon


import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.model.Polygon
import org.junit.Test
import org.junit.Assert.*

class PolygonUnitTest {
    //Remember, GeoJSON (longitude,latitude)
    private val horizontalTriangle = Polygon(
        listOf(
            listOf(0.0,0.0),
            listOf(2.0,0.0),
            listOf(1.0,1.0),
        )
    )

    private val verticalTriangle = Polygon(
        listOf(
            listOf(1.0,0.0),
            listOf(0.0,1.0),
            listOf(1.0,2.0),
        )
    )


    private val diamond = Polygon(
        listOf(
            listOf(1.0,0.0),
            listOf(0.0,1.0),
            listOf(1.0,2.0),
            listOf(2.0,1.0),
        )
    )
    private val square = Polygon(
        listOf(
            listOf(0.0,0.0),
            listOf(0.0,1.0),
            listOf(1.0,1.0),
            listOf(1.0,0.0),
        )
    )

    private val hexagon = Polygon(
        listOf(
            listOf(0.0,1.0),
            listOf(0.0,2.0),
            listOf(1.0,3.0),
            listOf(2.0,3.0),
            listOf(3.0,2.0),
            listOf(3.0,1.0),
            listOf(2.0,0.0),
            listOf(1.0,0.0)
        )
    )
    private val blockyM = Polygon(
        listOf(
            listOf(0.0,0.0),
            listOf(0.0,3.0),
            listOf(5.0,3.0),
            listOf(5.0,0.0),
            listOf(4.0,0.0),
            listOf(4.0,2.0),
            listOf(3.0,2.0),
            listOf(3.0,1.0),
            listOf(2.0,1.0),
            listOf(2.0,2.0),
            listOf(1.0,2.0),
            listOf(1.0,0.0)
        )
    )

    @Test
    fun `A coordinate that is higher than polygon with only slopedlines, won't be covered by polygon`(){
        assertFalse(diamond.covers(Coordinates("30","0")))
    }

    @Test
    fun `A coordinate that is higher than polygon of vertical and horizontal lines, won't be covered by polygon`(){
        assertFalse(square.covers(Coordinates("30","0")))
    }

    @Test
    fun `A coordinate that is higher than polygon of horizontal and sloped lines, won't be covered by polygon`(){
        assertFalse(horizontalTriangle.covers(Coordinates("30","0")))
    }

    @Test
    fun `A coordinate that is higher than polygon of vertical and sloped lines, won't be covered by polygon`(){
        assertFalse(verticalTriangle.covers(Coordinates("30","0")))
    }

    @Test
    fun `A coordinate that is higher than polygon of all linetypes, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("30","0")))
    }

    @Test
    fun `A coordinate that is lower than polygon of all linetypes, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("-10","0")))
    }

    @Test
    fun `A coordinate that is right of polygon of all linetypes, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("1.5","10")))
    }

    @Test
    fun `A coordinate that is left of polygon of all linetypes, crossing vertical line, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("1.5","-5")))
    }

    @Test
    fun `A coordinate that is left of polygon of all linetypes, crossing horizontal line, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("1.5","-5")))
    }

    @Test
    fun `A coordinate that is left of polygon of all linetypes, crossing sloped line, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("2.5","-5")))
    }

    @Test
    fun `A coordinate that is outside of polygon of all linetypes, but in the middle of two points of slopes line segment, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("0.4","0.4")))
    }

    @Test
    fun `A coordinate that is left of polygon of all linetypes, but at same height as a horizontal line, won't be covered by polygon`(){
        assertFalse(hexagon.covers(Coordinates("3.0","0")))
    }

    @Test
    fun `A coordinate that is within polygon of all linetypes, crossing a vertical line, is covered by polygon `(){
        assertTrue(hexagon.covers(Coordinates("1.5","1")))
    }

    @Test
    fun `A coordinate that is within polygon of all linetypes, crossing a sloped line, is covered by polygon `(){
        assertTrue(hexagon.covers(Coordinates("2.5","1.5")))
    }

    @Test
    fun `A coordinate that is on a polygons horizontal perimeter, is covered by polygon`(){
        assertTrue(hexagon.covers(Coordinates("3","1.5")))
    }

    @Test
    fun `A coordinate that is on a polygons vertical perimeter, is covered by polygon`(){
        assertTrue(hexagon.covers(Coordinates("1.5","0")))
    }

    @Test
    fun `A coordinate that is on a polygons sloped perimeter, is covered by polygon`(){
        assertTrue(hexagon.covers(Coordinates("2.5","0.5")))
    }

    @Test
    fun `A coordinate that is left of jagged polygon, is not covered by polygon`(){
        assertFalse(blockyM.covers(Coordinates("2.5","-5")))
    }

    @Test
    fun `A coordinate that is in jagged polygon, is covered by polygon`(){
        assertTrue(blockyM.covers(Coordinates("1.5","0.5")))
    }
}