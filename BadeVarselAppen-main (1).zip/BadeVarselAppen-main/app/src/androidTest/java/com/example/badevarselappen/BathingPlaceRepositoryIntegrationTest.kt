package com.example.badevarselappen

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.badevarselappen.data.BathingPlacesOslo
import com.example.badevarselappen.data.model.BathingPlace
import com.example.badevarselappen.data.model.Coordinates
import com.example.badevarselappen.data.database.BathingPlaceDatabase
import com.example.badevarselappen.data.database.FavoriteBathingPlaceDAO
import com.example.badevarselappen.data.database.bathingPlaceToDatabaseEntity
import com.example.badevarselappen.data.database.databaseEntityAsBathingPlace
import com.example.badevarselappen.data.repository.BathingPlaceRepository
import io.ktor.utils.io.errors.*
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BathingPlaceRepositoryIntegrationTest {
    private lateinit var dao: FavoriteBathingPlaceDAO
    private lateinit var db: BathingPlaceDatabase
    private val bathingPlaces = BathingPlacesOslo().bathingPlaces
    private lateinit var repository : BathingPlaceRepository

    @Before
    fun setupRepository() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(
            context,
            BathingPlaceDatabase::class.java
        ).allowMainThreadQueries().build()
        dao = db.favoriteBathingPlaceDAO
        repository = BathingPlaceRepository(
            favorites = db,
            standardList = bathingPlaces
        )
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    fun add_to_favorites_saves_to_db() = runBlocking {
        val bathingPlace = BathingPlace(Coordinates("1337","42"))
        assertEquals(0,dao.getAllFavoriteBathingPlaces().size)
        repository.addToFavorites(bathingPlace)
        assertEquals(1, dao.getAllFavoriteBathingPlaces().size)
        assertEquals(
            bathingPlace.name,
            dao.getFavoriteBathingPlaceByCoordinate(
                latitude = bathingPlace.coordinates.latitude,
                longitude = bathingPlace.coordinates.longitude
            )?.databaseEntityAsBathingPlace()?.name
        )
    }

    @Test
    fun deleting_from_favorites_removes_from_db() = runBlocking {
        val first = bathingPlaces.first()
        dao.insertFavoriteBathingPlace(first.bathingPlaceToDatabaseEntity())
        assertEquals(1,dao.getAllFavoriteBathingPlaces().size)
        repository.deleteFavorite(first)
        assertEquals(0,dao.getAllFavoriteBathingPlaces().size)
    }

    @Test
    fun getBathingPlace_returns_bathingplace_in_db_when_it_exists() = runBlocking {
        val bathingPlace = BathingPlace(Coordinates("1","2"))
        dao.insertFavoriteBathingPlace(bathingPlace.bathingPlaceToDatabaseEntity())
        assertEquals(bathingPlace,repository.getBathingPlace(bathingPlace.coordinates))
    }

    @Test
    fun getBathingPlace_returns_equals_standard_bathingplace_when_it_exist() = runBlocking {
        val first = bathingPlaces.first()
        assertEquals(0,dao.getAllFavoriteBathingPlaces().size)
        assertEquals(first,repository.getBathingPlace(first.coordinates))
    }

    @Test
    fun getBathingPlace_returns_new_bathingplace_when_it_doesnt_exist_in_db_or_in_standard() = runBlocking {
        val bathingPlace = BathingPlace("Name not coordinates",Coordinates("1","2"))
        assertNotEquals(bathingPlace,repository.getBathingPlace(bathingPlace.coordinates))
    }

    @Test
    fun isFavorite_returns_true_when_bathingplace_in_db() = runBlocking{
        val first = bathingPlaces.first()
        dao.insertFavoriteBathingPlace(first.bathingPlaceToDatabaseEntity())
        assertTrue(repository.isFavorite(first))
    }

    @Test
    fun isFavorite_returns_false_when_bathingplace_not_in_db() = runBlocking{
        val first = bathingPlaces.first()
        assertNull(dao.getFavoriteBathingPlaceByCoordinate(first.coordinates.latitude,first.coordinates.longitude))
        assertFalse(repository.isFavorite(first))
    }

    @Test
    fun getAllSortedFavoriteBathingPlaces_returns_all_objects_in_db() = runBlocking{
        bathingPlaces.forEach { dao.insertFavoriteBathingPlace(it.bathingPlaceToDatabaseEntity())}
        val list = repository.getAllSortedFavoriteBathingPlaces()
        assertEquals(bathingPlaces.size,list.size)
        list.forEachIndexed{ index, _ ->
            if(index != 0) assertTrue(list[index-1].name < list[index].name)
        }
    }

    @Test
    fun getAllFavoriteBathingPlacesSorted_gets_only_unique_bathing_places_and_they_are_sorted() = runBlocking{
        dao.insertFavoriteBathingPlace(bathingPlaces.first().bathingPlaceToDatabaseEntity())
        val list = repository.getAllSortedBathingPlaces()
        assertEquals(bathingPlaces.size,list.size)
        list.forEachIndexed{ index, _ ->
            if(index != 0) assertTrue(list[index-1].name < list[index].name)
        }
    }

    @Test
    fun repository_prioritizes_data_from_dataBase() = runBlocking {
        val last = bathingPlaces.last()
        val differentlast = last.copy(name = "new name")
        assertEquals(last, repository.getBathingPlace(last.coordinates))
        dao.insertFavoriteBathingPlace(differentlast.bathingPlaceToDatabaseEntity())
        assertEquals(differentlast, repository.getBathingPlace(last.coordinates))
        assertNotEquals(last,differentlast)
    }
}