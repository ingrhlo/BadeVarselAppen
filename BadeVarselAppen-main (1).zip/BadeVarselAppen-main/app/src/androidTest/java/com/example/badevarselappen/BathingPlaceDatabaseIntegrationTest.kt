package com.example.badevarselappen

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.badevarselappen.data.database.BathingPlaceDatabase
import com.example.badevarselappen.data.database.FavoriteBathingPlaceDAO
import com.example.badevarselappen.data.database.FavoriteBathingPlaceEntity
import io.ktor.utils.io.errors.*
import kotlinx.coroutines.runBlocking
import org.junit.After

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import org.junit.Before

@RunWith(AndroidJUnit4::class)
class BathingPlaceDatabaseIntegrationTest {
    private lateinit var dao : FavoriteBathingPlaceDAO
    private lateinit var db : BathingPlaceDatabase
    private val testEntities : List<FavoriteBathingPlaceEntity> = listOf(
        FavoriteBathingPlaceEntity("Test1","1","1"),
        FavoriteBathingPlaceEntity("Test2","1","1"),
        FavoriteBathingPlaceEntity("Test3","2","1"),
        FavoriteBathingPlaceEntity("Test4","1","2"),
        FavoriteBathingPlaceEntity("DuplicateName","2","2"),
        FavoriteBathingPlaceEntity("DuplicateName","1","1"),
    )
    private val onlyUniqueTestEntities : List<FavoriteBathingPlaceEntity> = listOf(
        FavoriteBathingPlaceEntity("Test1","1","1"),
        FavoriteBathingPlaceEntity("Test2","2","2"),
        FavoriteBathingPlaceEntity("Test3","3","3"),
        FavoriteBathingPlaceEntity("Test4","4","4"),
        FavoriteBathingPlaceEntity("DuplicateName","5","5"),
        FavoriteBathingPlaceEntity("DuplicateName","6","6"),
    )

    @Before
    fun createDb(){
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(
            context,
            BathingPlaceDatabase::class.java
        ).allowMainThreadQueries().build()
        dao = db.favoriteBathingPlaceDAO
    }

    @After
    @Throws(IOException::class)
    fun closeDb(){
        db.close()
    }

    @Test
    fun inserted_BathingPlace_is_saved() = runBlocking {
        val first = testEntities.first()
        dao.insertFavoriteBathingPlace(testEntities.first())
        assertEquals(first,dao.getFavoriteBathingPlaceByCoordinate(first.latitude,first.longitude))
    }

    @Test
    fun get_all_does_infact_get_all() = runBlocking {
        assertEquals(0,dao.getAllFavoriteBathingPlaces().size)
        onlyUniqueTestEntities.forEach { dao.insertFavoriteBathingPlace(it) }
        val list = dao.getAllFavoriteBathingPlaces()
        assertEquals(onlyUniqueTestEntities.size,list.size)
        assertTrue(list.containsAll(onlyUniqueTestEntities))

    }

    @Test
    fun delete_removes_from_database() = runBlocking {
        assertEquals(0,dao.getAllFavoriteBathingPlaces().size)
        val first = testEntities.first()
        dao.insertFavoriteBathingPlace(first)
        dao.deleteSelectedBathingPlace(first)
        dao.getFavoriteBathingPlaceByCoordinate(first.latitude,first.longitude)
        assertEquals(0,dao.getAllFavoriteBathingPlaces().size)
    }

    @Test
    fun inserting_on_key_that_exists_updates_entity() = runBlocking {
        val first = testEntities.first()
        dao.insertFavoriteBathingPlace(first)
        assertEquals(first.name,dao.getFavoriteBathingPlaceByCoordinate(first.latitude, first.longitude)?.name)

        val updated = first.copy(name = "NewestName")
        dao.insertFavoriteBathingPlace(updated)
        assertEquals(updated.name,dao.getFavoriteBathingPlaceByCoordinate(first.latitude,first.longitude)?.name)
    }

    @Test
    fun an_unsuccessful_get_returns_null(){
        val first = testEntities.first()
        assertNull(dao.getFavoriteBathingPlaceByCoordinate(first.latitude,first.longitude))
    }
}